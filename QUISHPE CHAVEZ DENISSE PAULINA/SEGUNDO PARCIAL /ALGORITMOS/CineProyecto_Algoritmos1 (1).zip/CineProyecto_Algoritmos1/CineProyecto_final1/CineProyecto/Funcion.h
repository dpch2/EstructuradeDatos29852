#ifndef FUNCION_H
#define FUNCION_H

#include "Pelicula.h"
#include <string>

class Funcion {
private:
    Pelicula* pelicula;
    std::string horario; // Ejemplo: "14:30" o "20:00"
    int salaId;
    std::string fecha; // Fecha de la función
public:
    Funcion(Pelicula* p, std::string h, int s) : pelicula(p), horario(h), salaId(s), fecha("") {}
    Funcion(Pelicula* p, std::string h, int s, std::string f) : pelicula(p), horario(h), salaId(s), fecha(f) {}
    Pelicula* getPelicula() { return pelicula; }
    std::string getHorario() { return horario; }
    int getSalaId() { return salaId; }
    std::string getFecha() { return fecha; }
    void setFecha(std::string f) { fecha = f; }
};

#endif