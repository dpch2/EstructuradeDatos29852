#include <iostream>
#include "ListaDobleCircular.h"
#include "AlgoritmosOrdenamiento.h"

int main() {
    ListaDobleCircular<int> lista;
    lista.insertarCola(5);
    lista.insertarCola(3);
    lista.insertarCola(8);
    lista.insertarCola(1);
    lista.insertarCola(7);

    auto cmp = [](int a, int b){ return a < b; };

    std::cout << "Original: "; lista.imprimir();
    AlgoritmosOrdenamiento<int>::mergeSort(lista, cmp);
    std::cout << "After mergeSort: "; lista.imprimir();

    // reverse to test quickSort
    lista.eliminarCabeza(); lista.eliminarCabeza(); lista.eliminarCabeza(); lista.eliminarCabeza(); lista.eliminarCabeza();
    lista.insertarCola(9); lista.insertarCola(4); lista.insertarCola(6); lista.insertarCola(2);
    std::cout << "Original2: "; lista.imprimir();
    AlgoritmosOrdenamiento<int>::quickSort(lista, cmp);
    std::cout << "After quickSort: "; lista.imprimir();

    // counting sort (values within 0..20)
    ListaDobleCircular<int> list2;
    int arr[] = {3,1,2,7,2,5,3,0,8,7};
    for (int v : arr) list2.insertarCola(v);
    std::cout << "Before counting: "; list2.imprimir();
    AlgoritmosOrdenamiento<int>::countingSort(list2, [](int x){ return x; }, 20);
    std::cout << "After counting: "; list2.imprimir();

    // radix sort
    ListaDobleCircular<int> list3;
    int arr2[] = {170,45,75,90,802,24,2,66};
    for (int v : arr2) list3.insertarCola(v);
    std::cout << "Before radix: "; list3.imprimir();
    AlgoritmosOrdenamiento<int>::radixSort(list3, [](int x){ return x; });
    std::cout << "After radix: "; list3.imprimir();

    // bucket sort uses double extractor
    ListaDobleCircular<int> list4;
    int arr3[] = {10,4,2,8,6,3};
    for (int v : arr3) list4.insertarCola(v);
    std::cout << "Before bucket: "; list4.imprimir();
    AlgoritmosOrdenamiento<int>::bucketSort(list4, [](int x){ return static_cast<double>(x); }, [](int a, int b){return a < b;});
    std::cout << "After bucket: "; list4.imprimir();

    return 0;
}
