#ifndef PELICULA_H
#define PELICULA_H

#include <string>

class Pelicula {
private:
    std::string nombre;
    int duracion; // en minutos
public:
    Pelicula(std::string n, int d) : nombre(n), duracion(d) {}
    std::string getNombre() { return nombre; }
    int getDuracion() { return duracion; }
};

#endif