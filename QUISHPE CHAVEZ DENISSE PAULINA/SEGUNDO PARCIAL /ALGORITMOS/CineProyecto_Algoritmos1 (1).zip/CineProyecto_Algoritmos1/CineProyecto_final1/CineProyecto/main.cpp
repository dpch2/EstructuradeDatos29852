#include "Modelo.h"
#include "Vista.h"
#include "Controlador.h"
#ifdef _WIN32
#include <windows.h>
static Modelo* g_modelo_for_handler = nullptr;
BOOL WINAPI ConsoleHandler(DWORD signal) {
    if (signal == CTRL_C_EVENT || signal == CTRL_CLOSE_EVENT || signal == CTRL_SHUTDOWN_EVENT) {
        if (g_modelo_for_handler) {
            g_modelo_for_handler->guardarReservas();
            g_modelo_for_handler->guardarUsuarios();
        }
    }
    return FALSE;
}
#endif

int main() {
    Modelo* modelo = new Modelo();
#ifdef _WIN32
    g_modelo_for_handler = modelo;
    SetConsoleCtrlHandler(ConsoleHandler, TRUE);
#endif
    Vista* vista = new Vista();
    Controlador* controlador = new Controlador(modelo, vista);
    
    controlador->ejecutar();
    
    delete controlador;
    delete vista;
    delete modelo;
    
    return 0;
}
 //g++ -std=c++11 main.cpp Controlador.cpp Modelo.cpp Vista.cpp Usuario.cpp Reserva.cpp Sala.cpp -o cine.exe
 //./cine.exe        