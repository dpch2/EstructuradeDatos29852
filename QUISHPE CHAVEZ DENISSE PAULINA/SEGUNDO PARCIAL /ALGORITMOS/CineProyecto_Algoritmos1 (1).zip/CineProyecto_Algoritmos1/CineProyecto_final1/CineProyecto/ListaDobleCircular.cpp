// Archivo vacío: las implementaciones de ListaDobleCircular están en ListaDobleCircular.h
// Esto evita redefiniciones de templates cuando se compilan múltiples archivos .cpp