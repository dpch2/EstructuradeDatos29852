#ifndef ALGORITMOSORDENAMIENTO_H
#define ALGORITMOSORDENAMIENTO_H

#include "ListaDobleCircular.h"
#include "Nodo.h"
#include <functional>
#include <cmath>
#include <vector>
#include <algorithm>

template <typename T>
class AlgoritmosOrdenamiento {
private:
    // Funciones auxiliares para Merge Sort
    static Nodo<T>* obtenerMedio(Nodo<T>* inicio, Nodo<T>* fin);
    static Nodo<T>* mergeSortRecursivo(Nodo<T>* inicio, Nodo<T>* fin, std::function<bool(T, T)> comparador);
    static Nodo<T>* merge(Nodo<T>* left, Nodo<T>* right, std::function<bool(T, T)> comparador);
    
    // Funciones auxiliares para Quick Sort
    static Nodo<T>* particion(Nodo<T>* inicio, Nodo<T>* fin, std::function<bool(T, T)> comparador);
    static void quickSortRecursivo(Nodo<T>* inicio, Nodo<T>* fin, std::function<bool(T, T)> comparador);
    
    // Funciones auxiliares para reconstruir lista
    static void hacerCircular(Nodo<T>* head, int size);
    static int contarNodos(Nodo<T>* inicio, Nodo<T>* fin);
    
public:
    // Algoritmos de ordenamiento simples O(n²)
    static void bubbleSort(ListaDobleCircular<T>& lista, std::function<bool(T, T)> comparador);
    static void selectionSort(ListaDobleCircular<T>& lista, std::function<bool(T, T)> comparador);
    static void insertionSort(ListaDobleCircular<T>& lista, std::function<bool(T, T)> comparador);
    
    // Algoritmos de ordenamiento eficientes O(n log n)
    static void mergeSort(ListaDobleCircular<T>& lista, std::function<bool(T, T)> comparador);
    static void quickSort(ListaDobleCircular<T>& lista, std::function<bool(T, T)> comparador);
    
    // Algoritmos de ordenamiento especializado
    static void bucketSort(ListaDobleCircular<T>& lista, std::function<double(T)> extractorValor, std::function<bool(T, T)> comparador);
    static void radixSort(ListaDobleCircular<T>& lista, std::function<int(T)> extractorEntero);
    static void countingSort(ListaDobleCircular<T>& lista, std::function<int(T)> extractorIndice, int maxValor);
};

// ==================== FUNCIONES AUXILIARES ====================

template <typename T>
void AlgoritmosOrdenamiento<T>::hacerCircular(Nodo<T>* head, int size) {
    if (head == nullptr || size == 0) return;
    
    Nodo<T>* tail = head;
    for (int i = 1; i < size; i++) {
        tail = tail->next;
    }
    
    tail->next = head;
    head->prev = tail;
}

template <typename T>
int AlgoritmosOrdenamiento<T>::contarNodos(Nodo<T>* inicio, Nodo<T>* fin) {
    int count = 0;
    Nodo<T>* current = inicio;
    while (current != fin) {
        count++;
        current = current->next;
    }
    return count + 1; // +1 para incluir el nodo fin
}

// ==================== BUBBLE SORT ====================
template <typename T>
void AlgoritmosOrdenamiento<T>::bubbleSort(ListaDobleCircular<T>& lista, std::function<bool(T, T)> comparador) {
    if (lista.getSize() <= 1) return;
    
    bool swapped;
    int n = lista.getSize();
    
    for (int i = 0; i < n - 1; i++) {
        swapped = false;
        Nodo<T>* current = lista.getHead();
        
        for (int j = 0; j < n - i - 1; j++) {
            Nodo<T>* siguiente = current->next;
            
            if (comparador(siguiente->data, current->data)) {
                T temp = current->data;
                current->data = siguiente->data;
                siguiente->data = temp;
                swapped = true;
            }
            
            current = current->next;
        }
        
        if (!swapped) break;
    }
}

// ==================== SELECTION SORT ====================
template <typename T>
void AlgoritmosOrdenamiento<T>::selectionSort(ListaDobleCircular<T>& lista, std::function<bool(T, T)> comparador) {
    if (lista.getSize() <= 1) return;
    
    Nodo<T>* inicio = lista.getHead();
    int n = lista.getSize();
    
    for (int i = 0; i < n - 1; i++) {
        Nodo<T>* minNodo = inicio;
        Nodo<T>* current = inicio->next;
        
        for (int j = i + 1; j < n; j++) {
            if (comparador(current->data, minNodo->data)) {
                minNodo = current;
            }
            current = current->next;
        }
        
        if (minNodo != inicio) {
            T temp = inicio->data;
            inicio->data = minNodo->data;
            minNodo->data = temp;
        }
        
        inicio = inicio->next;
    }
}

// ==================== INSERTION SORT ====================
template <typename T>
void AlgoritmosOrdenamiento<T>::insertionSort(ListaDobleCircular<T>& lista, std::function<bool(T, T)> comparador) {
    if (lista.getSize() <= 1) return;
    
    Nodo<T>* sorted = lista.getHead();
    Nodo<T>* current = sorted->next;
    int n = lista.getSize();
    
    for (int i = 1; i < n; i++) {
        T key = current->data;
        Nodo<T>* j = current->prev;
        
        int pasos = i;
        while (pasos > 0 && comparador(key, j->data)) {
            j->next->data = j->data;
            j = j->prev;
            pasos--;
        }
        
        j->next->data = key;
        current = current->next;
    }
}

// ==================== MERGE SORT ====================
template <typename T>
Nodo<T>* AlgoritmosOrdenamiento<T>::obtenerMedio(Nodo<T>* inicio, Nodo<T>* fin) {
    if (inicio == nullptr) return nullptr;
    
    Nodo<T>* slow = inicio;
    Nodo<T>* fast = inicio->next;
    
    while (fast != fin) {
        fast = fast->next;
        if (fast != fin) {
            slow = slow->next;
            fast = fast->next;
        }
    }
    
    return slow;
}

template <typename T>
Nodo<T>* AlgoritmosOrdenamiento<T>::merge(Nodo<T>* left, Nodo<T>* right, std::function<bool(T, T)> comparador) {
    if (left == nullptr) return right;
    if (right == nullptr) return left;
    
    Nodo<T>* result = nullptr;
    
    if (comparador(left->data, right->data)) {
        result = left;
        result->next = merge(left->next, right, comparador);
        if (result->next) result->next->prev = result;
    } else {
        result = right;
        result->next = merge(left, right->next, comparador);
        if (result->next) result->next->prev = result;
    }
    
    return result;
}

template <typename T>
Nodo<T>* AlgoritmosOrdenamiento<T>::mergeSortRecursivo(Nodo<T>* inicio, Nodo<T>* fin, std::function<bool(T, T)> comparador) {
    if (inicio == nullptr || inicio == fin) {
        return inicio;
    }
    
    Nodo<T>* medio = obtenerMedio(inicio, fin);
    Nodo<T>* siguienteMedio = medio->next;
    
    medio->next = nullptr;
    if (siguienteMedio) siguienteMedio->prev = nullptr;
    
    Nodo<T>* left = mergeSortRecursivo(inicio, medio, comparador);
    Nodo<T>* right = mergeSortRecursivo(siguienteMedio, fin, comparador);
    
    return merge(left, right, comparador);
}

template <typename T>
void AlgoritmosOrdenamiento<T>::mergeSort(ListaDobleCircular<T>& lista, std::function<bool(T, T)> comparador) {
    // Implementación segura: copiar datos a un vector, ordenar y reconstruir
    if (lista.getSize() <= 1) return;

    std::vector<T> datos;
    Nodo<T>* cur = lista.getHead();
    Nodo<T>* inicio = cur;
    do {
        datos.push_back(cur->data);
        cur = cur->next;
    } while (cur != inicio);

    // Ordenar el vector con el comparador
    std::sort(datos.begin(), datos.end(), [&](const T &a, const T &b){ return comparador(a,b); });

    // Limpiar la lista original
    while (lista.getSize() > 0) lista.eliminarCabeza();

    // Reconstruir la lista a partir del vector ordenado
    for (const T &v : datos) lista.insertarCola(v);
}

// ==================== QUICK SORT ====================
template <typename T>
Nodo<T>* AlgoritmosOrdenamiento<T>::particion(Nodo<T>* inicio, Nodo<T>* fin, std::function<bool(T, T)> comparador) {
    T pivot = fin->data;
    Nodo<T>* i = inicio->prev;
    
    for (Nodo<T>* j = inicio; j != fin; j = j->next) {
        if (comparador(j->data, pivot) || (!comparador(pivot, j->data) && !comparador(j->data, pivot))) {
            i = (i == nullptr) ? inicio : i->next;
            
            T temp = i->data;
            i->data = j->data;
            j->data = temp;
        }
    }
    
    i = (i == nullptr) ? inicio : i->next;
    T temp = i->data;
    i->data = fin->data;
    fin->data = temp;
    
    return i;
}

template <typename T>
void AlgoritmosOrdenamiento<T>::quickSortRecursivo(Nodo<T>* inicio, Nodo<T>* fin, std::function<bool(T, T)> comparador) {
    if (fin != nullptr && inicio != fin && inicio != fin->next) {
        Nodo<T>* pivot = particion(inicio, fin, comparador);
        quickSortRecursivo(inicio, pivot->prev, comparador);
        quickSortRecursivo(pivot->next, fin, comparador);
    }
}

template <typename T>
void AlgoritmosOrdenamiento<T>::quickSort(ListaDobleCircular<T>& lista, std::function<bool(T, T)> comparador) {
    if (lista.getSize() <= 1) return;
    
    Nodo<T>* head = lista.getHead();
    Nodo<T>* tail = head->prev;
    
    // Romper circularidad temporalmente
    tail->next = nullptr;
    head->prev = nullptr;
    
    // Encontrar verdadero tail
    Nodo<T>* realTail = head;
    while (realTail->next != nullptr) {
        realTail = realTail->next;
    }
    
    quickSortRecursivo(head, realTail, comparador);
    
    // Restaurar circularidad
    hacerCircular(head, lista.getSize());
}

// ==================== BUCKET SORT ====================
template <typename T>
void AlgoritmosOrdenamiento<T>::bucketSort(ListaDobleCircular<T>& lista, 
                                           std::function<double(T)> extractorValor,
                                           std::function<bool(T, T)> comparador) {
    if (lista.getSize() <= 1) return;
    
    int n = lista.getSize();
    
    // Crear array de buckets usando listas
    ListaDobleCircular<T>* buckets = new ListaDobleCircular<T>[n];
    
    // Encontrar min y max
    Nodo<T>* current = lista.getHead();
    Nodo<T>* inicio = current;
    double minVal = extractorValor(current->data);
    double maxVal = minVal;
    
    do {
        double val = extractorValor(current->data);
        if (val < minVal) minVal = val;
        if (val > maxVal) maxVal = val;
        current = current->next;
    } while (current != inicio);
    
    // Distribuir en buckets
    double range = maxVal - minVal;
    if (range == 0) {
        delete[] buckets;
        return;
    }
    
    current = lista.getHead();
    do {
        double val = extractorValor(current->data);
        int bucketIndex = static_cast<int>((val - minVal) / range * (n - 1));
        buckets[bucketIndex].insertarCola(current->data);
        current = current->next;
    } while (current != inicio);
    
    // Ordenar cada bucket con insertion sort
    for (int i = 0; i < n; i++) {
        if (buckets[i].getSize() > 1) {
            insertionSort(buckets[i], comparador);
        }
    }
    
    // Reconstruir lista original
    while (lista.getSize() > 0) {
        lista.eliminarCabeza();
    }
    
    for (int i = 0; i < n; i++) {
        Nodo<T>* bucketNode = buckets[i].getHead();
        if (bucketNode != nullptr) {
            Nodo<T>* bucketInicio = bucketNode;
            do {
                lista.insertarCola(bucketNode->data);
                bucketNode = bucketNode->next;
            } while (bucketNode != bucketInicio);
        }
    }
    
    delete[] buckets;
}

// ==================== RADIX SORT ====================
template <typename T>
void AlgoritmosOrdenamiento<T>::radixSort(ListaDobleCircular<T>& lista, 
                                          std::function<int(T)> extractorEntero) {
    if (lista.getSize() <= 1) return;
    
    // Encontrar el máximo
    Nodo<T>* current = lista.getHead();
    Nodo<T>* inicio = current;
    int maxNum = extractorEntero(current->data);
    
    do {
        int num = extractorEntero(current->data);
        if (num > maxNum) maxNum = num;
        current = current->next;
    } while (current != inicio);
    
    // Ordenar por cada dígito
    for (int exp = 1; maxNum / exp > 0; exp *= 10) {
        ListaDobleCircular<T> buckets[10];
        
        current = lista.getHead();
        inicio = current;
        do {
            int digit = (extractorEntero(current->data) / exp) % 10;
            buckets[digit].insertarCola(current->data);
            current = current->next;
        } while (current != inicio);
        
        // Reconstruir lista
        while (lista.getSize() > 0) {
            lista.eliminarCabeza();
        }
        
        for (int i = 0; i < 10; i++) {
            Nodo<T>* bucketNode = buckets[i].getHead();
            if (bucketNode != nullptr) {
                Nodo<T>* bucketInicio = bucketNode;
                do {
                    lista.insertarCola(bucketNode->data);
                    bucketNode = bucketNode->next;
                } while (bucketNode != bucketInicio);
            }
        }
    }
}

// ==================== COUNTING SORT ====================
template <typename T>
void AlgoritmosOrdenamiento<T>::countingSort(ListaDobleCircular<T>& lista, 
                                             std::function<int(T)> extractorIndice, 
                                             int maxValor) {
    if (lista.getSize() <= 1) return;
    
    // Crear array de conteo
    int* count = new int[maxValor + 1];
    for (int i = 0; i <= maxValor; i++) {
        count[i] = 0;
    }
    
    // Crear lista temporal para almacenar elementos
    ListaDobleCircular<T> temp;
    
    // Contar ocurrencias y copiar a temp
    Nodo<T>* current = lista.getHead();
    Nodo<T>* inicio = current;
    do {
        int index = extractorIndice(current->data);
        if (index >= 0 && index <= maxValor) {
            count[index]++;
            temp.insertarCola(current->data);
        }
        current = current->next;
    } while (current != inicio);
    
    // Acumular conteos
    for (int i = 1; i <= maxValor; i++) {
        count[i] += count[i - 1];
    }
    
    // Crear array de salida usando lista
    ListaDobleCircular<T> output;
    for (int i = 0; i < temp.getSize(); i++) {
        output.insertarCola(T()); // Placeholder
    }
    
    // Construir array ordenado
    Nodo<T>* tempNode = temp.getHead();
    if (tempNode != nullptr) {
        Nodo<T>* tempInicio = tempNode;
        int size = temp.getSize();
        
        // Procesar desde el final (tail)
        tempNode = tempNode->prev; // ahora apunta al último elemento (tail)
        for (int i = size - 1; i >= 0; i--) {
            int index = extractorIndice(tempNode->data);
            if (index >= 0 && index <= maxValor) {
                int pos = count[index] - 1;

                // Insertar en posición correcta (recorrer output hasta pos)
                Nodo<T>* outNode = output.getHead();
                for (int j = 0; j < pos; j++) {
                    outNode = outNode->next;
                }
                outNode->data = tempNode->data;

                count[index]--;
            }
            tempNode = tempNode->prev;
        }
    }
    
    // Reconstruir lista original
    while (lista.getSize() > 0) {
        lista.eliminarCabeza();
    }
    
    Nodo<T>* outNode = output.getHead();
    if (outNode != nullptr) {
        Nodo<T>* outInicio = outNode;
        do {
            lista.insertarCola(outNode->data);
            outNode = outNode->next;
        } while (outNode != outInicio);
    }
    
    delete[] count;
}

#endif