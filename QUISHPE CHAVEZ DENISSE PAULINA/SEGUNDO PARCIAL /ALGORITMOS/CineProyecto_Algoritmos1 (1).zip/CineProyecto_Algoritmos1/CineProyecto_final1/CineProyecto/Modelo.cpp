#include "Modelo.h"
#include "include/json.hpp"
#include <vector>
#include <set>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <iterator>
#include <chrono>
#include <cstdlib>

Modelo::Modelo() {
    // Películas predefinidas con duración
    Pelicula* p1 = new Pelicula("Avatar: El camino del agua", 192);
    Pelicula* p2 = new Pelicula("John Wick 4", 169);
    Pelicula* p3 = new Pelicula("Oppenheimer", 180);
    peliculas.insertarCola(p1);
    peliculas.insertarCola(p2);
    peliculas.insertarCola(p3);

    // Salas predefinidas
    for (int i = 1; i <= 6; i++) {
        Sala* s = new Sala(i);
        salas.insertarCola(s);
    }

    // Funciones predefinidas (2 por película con horarios específicos)
    funciones.insertarCola(new Funcion(p1, "14:30", 1));
    funciones.insertarCola(new Funcion(p1, "20:00", 2));
    funciones.insertarCola(new Funcion(p2, "15:00", 3));
    funciones.insertarCola(new Funcion(p2, "21:30", 4));
    funciones.insertarCola(new Funcion(p3, "16:00", 5));
    funciones.insertarCola(new Funcion(p3, "23:30", 6));

    // cargar usuarios antes de reservas para poder asociar reservas con usuarios existentes
    cargarUsuarios();
    cargarReservas();
}

void Modelo::agregarReserva(Reserva* r) {
    reservas.insertarCola(r);
    guardarReservas();
}

void Modelo::eliminarReserva(Reserva* r) {
    Nodo<Reserva*>* current = reservas.getHead();
    if (current == nullptr) return;
    
    do {
        if (current->data == r) {
            // Liberar asientos de la reserva
            Nodo<Asiento*>* asiento = r->getAsientos().getHead();
            if (asiento != nullptr) {
                do {
                    asiento->data->liberar();
                    asiento = asiento->next;
                } while (asiento != r->getAsientos().getHead());
            }
            
            // Eliminar de la lista
            if (reservas.getSize() == 1) {
                reservas.eliminarCabeza();
            } else {
                if (current == reservas.getHead()) {
                    reservas.eliminarCabeza();
                } else {
                    current->prev->next = current->next;
                    current->next->prev = current->prev;
                    delete current;
                }
            }
            guardarReservas();
            return;
        }
        current = current->next;
    } while (current != reservas.getHead());
}

void Modelo::agregarUsuario(Usuario* u) {
    usuarios.insertarCola(u);
}

Usuario* Modelo::buscarUsuarioPorCedula(std::string cedula) {
    Nodo<Usuario*>* current = usuarios.getHead();
    if (current == nullptr) return nullptr;
    
    do {
        if (current->data->getCedula() == cedula) {
            return current->data;
        }
        current = current->next;
    } while (current != usuarios.getHead());
    
    return nullptr;
}

void Modelo::guardarReservas() {
    // Hacer backup del archivo anterior
    std::ifstream src("reservas.txt");
    if (src.is_open()) {
        src.close();
        #ifdef _WIN32
        system("copy reservas.txt reservas.txt.bak >nul 2>&1");
        #else
        system("cp reservas.txt reservas.txt.bak 2>/dev/null");
        #endif
    }

    toon::TOON reservasArray = toon::TOON::array();
    Nodo<Reserva*>* current = reservas.getHead();
    if (current != nullptr) {
        do {
            reservasArray.push_back(current->data->toToon());
            current = current->next;
        } while (current != reservas.getHead());
    }
    std::ofstream file("reservas.txt");
    file << reservasArray.dump(2);
    file.close();
}

void Modelo::guardarUsuarios() {
    // Hacer backup del archivo anterior
    std::ifstream src("usuarios.txt");
    if (src.is_open()) {
        src.close();
        #ifdef _WIN32
        system("copy usuarios.txt usuarios.txt.bak >nul 2>&1");
        #else
        system("cp usuarios.txt usuarios.txt.bak 2>/dev/null");
        #endif
    }

    toon::TOON usuariosArray = toon::TOON::array();
    Nodo<Usuario*>* cur = usuarios.getHead();
    if (cur != nullptr) {
        do {
            usuariosArray.push_back(cur->data->toToon());
            cur = cur->next;
        } while (cur != usuarios.getHead());
    }
    std::ofstream f("usuarios.txt");
    f << usuariosArray.dump(2);
    f.close();
}

void Modelo::cargarReservas() {
    std::ifstream file("reservas.txt");
    if (!file.is_open()) return;
    std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    file.close();

    try {
        nlohmann::json j = nlohmann::json::parse(content);
        if (!j.is_array()) return;
        std::ofstream errlog("load_errors.log", std::ios::app);
        for (const auto& item : j) {
            // convertir json -> toon::TOON
            toon::TOON to = toon::TOON::object();
            if (item.contains("usuario")) {
                toon::TOON u = toon::TOON::object();
                const auto& ju = item["usuario"];
                if (ju.contains("nombre")) u["nombre"] = toon::TOON(ju["nombre"].get<std::string>());
                if (ju.contains("edad")) u["edad"] = toon::TOON(ju["edad"].get<int>());
                if (ju.contains("genero")) u["genero"] = toon::TOON(ju["genero"].get<std::string>());
                if (ju.contains("cedula")) u["cedula"] = toon::TOON(ju["cedula"].get<std::string>());
                if (ju.contains("direccion")) u["direccion"] = toon::TOON(ju["direccion"].get<std::string>());
                if (ju.contains("telefono")) u["telefono"] = toon::TOON(ju["telefono"].get<std::string>());
                to["usuario"] = u;
            }
            if (item.contains("funcionId")) to["funcionId"] = toon::TOON(item["funcionId"].get<int>());
            if (item.contains("horario")) to["horario"] = toon::TOON(item["horario"].get<std::string>());
            if (item.contains("fecha")) to["fecha"] = toon::TOON(item["fecha"].get<std::string>());
            if (item.contains("total")) to["total"] = toon::TOON(item["total"].get<double>());
            if (item.contains("asientos")) {
                toon::TOON arr = toon::TOON::array();
                for (const auto& a : item["asientos"]) {
                    arr.push_back(toon::TOON(a.get<std::string>()));
                }
                to["asientos"] = arr;
            }

            // recolectar lista esperada de asientos para comparar luego
            std::vector<std::string> expectedSeats;
            if (item.contains("asientos")) {
                for (const auto& a : item["asientos"]) expectedSeats.push_back(a.get<std::string>());
            }

            Reserva* r = Reserva::fromToon(to, this);
            if (r) {
                reservas.insertarCola(r);
                // Marcar asientos como ocupados inmediatamente
                Nodo<Asiento*>* a = r->getAsientos().getHead();
                int cnt = 0;
                if (a) {
                    Nodo<Asiento*>* inicioA = a;
                    do { a->data->ocupar(); a = a->next; cnt++; } while (a != inicioA);
                }
                // Log de carga
                std::cout << "[CARGA] Reserva cargada: Cliente=" << r->getUsuario()->getNombre()
                          << " Cedula=" << r->getUsuario()->getCedula()
                          << " Fecha=" << r->getFecha()
                          << " Sala=" << r->getFuncion()->getSalaId()
                          << " Horario=" << r->getFuncion()->getHorario()
                          << " AsientosCargados=" << cnt
                          << " Total=$" << std::fixed << std::setprecision(2) << r->getTotal()
                          << std::endl;

                // comparar asientos esperados vs cargados y registrar errores si faltan
                std::set<std::string> loaded;
                Nodo<Asiento*>* ac = r->getAsientos().getHead();
                if (ac) {
                    Nodo<Asiento*>* inicioAc = ac;
                    do { loaded.insert(ac->data->getId()); ac = ac->next; } while (ac != inicioAc);
                }
                std::vector<std::string> missing;
                for (const auto& ex : expectedSeats) if (loaded.find(ex) == loaded.end()) missing.push_back(ex);
                if (!missing.empty()) {
                    // Construir JSON-line con timestamp y detalles
                    nlohmann::json e;
                    auto now = std::chrono::system_clock::now();
                    std::time_t tnow = std::chrono::system_clock::to_time_t(now);
                    std::tm tm = *std::localtime(&tnow);
                    std::ostringstream tss; tss << std::put_time(&tm, "%Y-%m-%dT%H:%M:%S");
                    e["timestamp"] = tss.str();
                    e["type"] = "missing_seats";
                    e["cliente"] = r->getUsuario()->getNombre();
                    e["cedula"] = r->getUsuario()->getCedula();
                    e["fecha"] = r->getFecha();
                    e["sala"] = r->getFuncion()->getSalaId();
                    e["horario"] = r->getFuncion()->getHorario();
                    e["missing"] = nlohmann::json::array();
                    for (const auto& m : missing) e["missing"].push_back(m);
                    std::string line = e.dump();
                    std::cout << "[ERROR CARGA] " << line << std::endl;
                    if (errlog.is_open()) errlog << line << std::endl;
                }
            } else {
                nlohmann::json e;
                auto now = std::chrono::system_clock::now();
                std::time_t tnow = std::chrono::system_clock::to_time_t(now);
                std::tm tm = *std::localtime(&tnow);
                std::ostringstream tss; tss << std::put_time(&tm, "%Y-%m-%dT%H:%M:%S");
                e["timestamp"] = tss.str();
                e["type"] = "omitted_reservation";
                // intentar extraer cedula/nombre/hora si existen en 'to'
                const toon::TOON* u = to.get("usuario");
                if (u && u->get("nombre")) e["cliente"] = u->get("nombre")->string_value;
                if (u && u->get("cedula")) e["cedula"] = u->get("cedula")->string_value;
                if (to.get("horario")) e["horario"] = to.get("horario")->string_value;
                if (to.get("funcionId")) e["sala"] = static_cast<int>(to.get("funcionId")->number_value);
                e["reason"] = "usuario o funcion no encontrados";
                std::string line = e.dump();
                std::cout << "[CARGA] " << line << std::endl;
                if (errlog.is_open()) errlog << line << std::endl;
            }
        }
        if (errlog.is_open()) errlog.close();
    } catch (...) {
        // parsing fallido, ignorar
        return;
    }
}

void Modelo::actualizarAsientosEnSala(Sala* sala, std::string fecha) {
    // Liberar todos los asientos de la sala primero
    Nodo<Asiento*>* current = sala->getAsientos().getHead();
    if (current == nullptr) return;
    
    do {
        current->data->liberar();
        current = current->next;
    } while (current != sala->getAsientos().getHead());
    
    // Ocupar asientos según las reservas de esta sala y fecha
    Nodo<Reserva*>* resPtr = reservas.getHead();
    if (resPtr != nullptr) {
        Nodo<Reserva*>* inicio = resPtr;
        do {
            // Verificar si la reserva es para esta sala y fecha
            if (resPtr->data->getFuncion()->getSalaId() == sala->getId() && 
                resPtr->data->getFecha() == fecha) {
                // Ocupar los asientos de esta reserva
                Nodo<Asiento*>* asientoPtr = resPtr->data->getAsientos().getHead();
                if (asientoPtr != nullptr) {
                    Nodo<Asiento*>* inicioAsiento = asientoPtr;
                    do {
                        asientoPtr->data->ocupar();
                        asientoPtr = asientoPtr->next;
                    } while (asientoPtr != inicioAsiento);
                }
            }
            resPtr = resPtr->next;
        } while (resPtr != inicio);
    }
}

void Modelo::cargarUsuarios() {
    std::ifstream file("usuarios.txt");
    if (!file.is_open()) return;
    std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    file.close();
    try {
        nlohmann::json j = nlohmann::json::parse(content);
        if (!j.is_array()) return;
        for (const auto& item : j) {
            toon::TOON to = toon::TOON::object();
            if (item.contains("nombre")) to["nombre"] = toon::TOON(item["nombre"].get<std::string>());
            if (item.contains("edad")) to["edad"] = toon::TOON(item["edad"].get<int>());
            if (item.contains("genero")) to["genero"] = toon::TOON(item["genero"].get<std::string>());
            if (item.contains("cedula")) to["cedula"] = toon::TOON(item["cedula"].get<std::string>());
            if (item.contains("direccion")) to["direccion"] = toon::TOON(item["direccion"].get<std::string>());
            if (item.contains("telefono")) to["telefono"] = toon::TOON(item["telefono"].get<std::string>());
            Usuario* u = Usuario::fromToon(to);
            if (u) usuarios.insertarCola(u);
        }
    } catch (...) {
        return;
    }
}

Modelo::~Modelo() {
    // Guardar datos antes de destruir
    guardarReservas();
    guardarUsuarios();
}