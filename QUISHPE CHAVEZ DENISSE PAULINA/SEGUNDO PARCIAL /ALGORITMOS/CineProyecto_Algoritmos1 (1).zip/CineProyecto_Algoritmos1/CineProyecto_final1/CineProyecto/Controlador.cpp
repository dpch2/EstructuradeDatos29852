#include "Controlador.h"
#include "Sala.h"
#include <ctime>
#include <cstdlib>
#include <iomanip>
#include <sstream>
#include <cctype>
#include <algorithm>
#include <cmath>
#include "AlgoritmosOrdenamiento.h"
#include <chrono>

void Controlador::ejecutar() {
    int opcion;
    do {
        vista->mostrarMenu();
        opcion = vista->leerIntEnRango("Seleccione una opcion: ", 1, 5);
        
        switch (opcion) {
        case 1:
            registrarReserva();
            break;
        case 2:
            verReporte();
            break;
        case 3:
            cancelarReserva();
            break;
        case 4:
            // Saltamos el menu general de ordenamiento y vamos directo al criterio de RESERVAS
            ordenarReservas();
            break;
        case 5:
            vista->mostrarMensaje("\nGracias por usar el sistema! Adios.");
            break;
        default:
            break;
        }
    } while (opcion != 5);
}

std::string Controlador::convertirAMinusculas(const std::string& texto) {
    std::string out = texto;
    std::transform(out.begin(), out.end(), out.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); });
    return out;
}

Usuario* Controlador::obtenerORegistrarUsuario() {
    vista->mostrarMensaje("\n=== DATOS DEL CLIENTE ===");
    
    while (true) {
        // Validar cedula primero
        std::string cedula;
        bool cedulaValida = false;
        do {
            cedula = vista->leerString("Ingrese cedula (10 digitos numericos) o '0' para cancelar: ");
            if (cedula == "0") return nullptr;
            
            Usuario tempUser("Temp", 18, "Hombre", cedula, "Dir", "0000000000");
            if (tempUser.validarCedula()) cedulaValida = true;
            else vista->mostrarMensaje("[ERROR] La cedula debe tener exactamente 10 digitos numericos.");
        } while (!cedulaValida);
        
        // buscar usuario
        Usuario* usuarioExistente = modelo->buscarUsuarioPorCedula(cedula);
        if (usuarioExistente != nullptr) {
            vista->mostrarMensaje("\n[INFO] Cliente encontrado:");
            vista->mostrarMensaje("1. Usar este cliente");
            vista->mostrarMensaje("2. Ingresar otra cedula");
            vista->mostrarMensaje("0. Regresar");
            int opt = vista->leerIntEnRango("Seleccione opcion: ", 0, 2);
            if (opt == 1) return usuarioExistente;
            if (opt == 0) return nullptr;
            // else loop para reingresar cedula
            continue;
        }
        
        // registrar nuevo
        vista->mostrarMensaje("\n[INFO] Cliente no encontrado. Nuevo registro (0 cancela en cualquier campo).");
        
        // nombre
        std::string nombre;
        while (true) {
            nombre = vista->leerString("Nombre completo (solo letras) o '0' para cancelar: ");
            if (nombre == "0") return nullptr;
            Usuario tempNombre(nombre, 18, "Hombre", cedula, "Dir", "0000000000");
            if (tempNombre.validarNombre()) break;
            vista->mostrarMensaje("[ERROR] El nombre solo debe contener letras y espacios.");
        }
        
        int edad = vista->leerIntEnRango("Edad (mayores de 18): ", 18, 120);
        
        // genero acepta cualquier case
        std::string genero;
        while (true) {
            genero = vista->leerString("Genero (Hombre/Mujer) o '0' para cancelar: ");
            if (genero == "0") return nullptr;
            std::string gmin = convertirAMinusculas(genero);
            if (gmin == "hombre") { genero = "Hombre"; break; }
            if (gmin == "mujer")  { genero = "Mujer";  break; }
            vista->mostrarMensaje("[ERROR] Debe escribir 'Hombre' o 'Mujer'.");
        }
        
        std::string direccion = vista->leerString("Direccion (o '0' para cancelar): ");
        if (direccion == "0") return nullptr;
        
        std::string telefono;
        while (true) {
            telefono = vista->leerString("Telefono (10 digitos) o '0' para cancelar: ");
            if (telefono == "0") return nullptr;
            Usuario tempTel(nombre, edad, genero, cedula, direccion, telefono);
            if (tempTel.validarTelefono()) break;
            vista->mostrarMensaje("[ERROR] El telefono debe tener exactamente 10 digitos.");
        }
        
        // confirmar guardar
        vista->mostrarMensaje("\n1. Registrar cliente");
        vista->mostrarMensaje("2. Cancelar y regresar al menu principal");
        int confirmar = vista->leerIntEnRango("Seleccione opcion: ", 1, 2);
        if (confirmar == 2) return nullptr;
        
        Usuario* nuevoUsuario = new Usuario(nombre, edad, genero, cedula, direccion, telefono);
        if (!nuevoUsuario->esValido()) {
            vista->mostrarMensaje("[ERROR] Datos invalidos. Intente de nuevo.");
            delete nuevoUsuario;
            continue;
        }
        modelo->agregarUsuario(nuevoUsuario);
        vista->mostrarMensaje("\n[EXITO] Cliente registrado correctamente.");
        return nuevoUsuario;
    }
}

std::string Controlador::obtenerFechaFormato(int diasDesdeHoy) {
    time_t now = time(0);
    time_t futuro = now + static_cast<time_t>(diasDesdeHoy) * 86400;
    tm* ltm = localtime(&futuro);
    std::stringstream ss;
    ss << std::setfill('0') << std::setw(2) << ltm->tm_mday << "/"
       << std::setfill('0') << std::setw(2) << (1 + ltm->tm_mon) << "/"
       << (1900 + ltm->tm_year);
    return ss.str();
}

void Controlador::seleccionarFechas() {
    vista->mostrarMensaje("\nSeleccione fecha:");
    std::string f0 = obtenerFechaFormato(0);
    std::string f1 = obtenerFechaFormato(1);
    std::string f2 = obtenerFechaFormato(2);
    vista->mostrarMensaje("1. " + f0 + " (Hoy)");
    vista->mostrarMensaje("2. " + f1 + " (Manana)");
    vista->mostrarMensaje("3. " + f2 + " (Pasado manana)");
    vista->mostrarMensaje("0. Regresar");
}

void Controlador::mostrarPeliculasPorFecha(const std::string& fecha) {
    vista->mostrarMensaje("\nPeliculas para " + fecha + ":");
    Nodo<Pelicula*>* head = modelo->getPeliculas().getHead();
    if (!head) { vista->mostrarMensaje("[INFO] No hay peliculas."); return; }
    Nodo<Pelicula*>* inicio = head;
    int idx = 1;
    do {
        std::cout << idx << ". " << head->data->getNombre() << " (" << head->data->getDuracion() << " min)\n";
        head = head->next; idx++;
    } while (head != inicio);
    vista->mostrarMensaje("0. Regresar");
}

void Controlador::registrarReserva() {
    vista->mostrarMensaje("\n=== REGISTRO DE NUEVA RESERVA ===");
    
    Usuario* usuario = obtenerORegistrarUsuario();
    if (!usuario) return;
    
    // elegir fecha
    seleccionarFechas();
    int optFecha = vista->leerIntEnRango("Seleccione fecha: ", 0, 3);
    if (optFecha == 0) return;
    std::string fecha = obtenerFechaFormato(optFecha - 1);
    mostrarPeliculasPorFecha(fecha);
    
    // elegir pelicula
    ListaDobleCircular<Pelicula*>& listaPelis = modelo->getPeliculas();
    int pelCount = listaPelis.getSize();
    if (pelCount == 0) { vista->mostrarMensaje("[ERROR] No hay peliculas disponibles."); return; }
    int pelSeleccion = vista->leerIntEnRango("Seleccione pelicula (numero) o 0 regresar: ", 0, pelCount);
    if (pelSeleccion == 0) return;
    // obtener pelicula por indice
    Nodo<Pelicula*>* curP = listaPelis.getHead();
    Nodo<Pelicula*>* inicioP = curP;
    for (int i=1;i<pelSeleccion;i++) curP = curP->next;
    Pelicula* peliculaSeleccionada = curP->data;
    
    // mostrar funciones (sin fecha real en modelo pero mostramos horarios)
    vista->mostrarMensaje("\n=== HORARIOS DISPONIBLES ===");
    ListaDobleCircular<Funcion*> funcionesDisponibles;
    Nodo<Funcion*>* cf = modelo->getFunciones().getHead();
    if (cf) {
        Nodo<Funcion*>* inicioF = cf;
        int num = 1;
        do {
            if (cf->data->getPelicula() == peliculaSeleccionada) {
                std::cout << num << ". " << cf->data->getHorario() << " - Sala " << cf->data->getSalaId() << std::endl;
                funcionesDisponibles.insertarCola(cf->data);
                num++;
            }
            cf = cf->next;
        } while (cf != inicioF);
    }
    vista->mostrarMensaje("0. Regresar");
    if (funcionesDisponibles.getSize() == 0) { vista->mostrarMensaje("[ERROR] No hay funciones."); return; }
    int horSeleccion = vista->leerIntEnRango("Seleccione horario: ", 0, funcionesDisponibles.getSize());
    if (horSeleccion == 0) return;
    // obtener funcion seleccionada
    Nodo<Funcion*>* selF = funcionesDisponibles.getHead();
    for (int i=1;i<horSeleccion;i++) selF = selF->next;
    Funcion* funcionSeleccionada = selF->data;
    
    // buscar sala asignada
    Sala* salaSeleccionada = nullptr;
    Nodo<Sala*>* cs = modelo->getSalas().getHead();
    if (cs) {
        Nodo<Sala*>* inicioS = cs;
        do {
            if (cs->data->getId() == funcionSeleccionada->getSalaId()) { salaSeleccionada = cs->data; break; }
            cs = cs->next;
        } while (cs != inicioS);
    }
    if (!salaSeleccionada) { vista->mostrarMensaje("[ERROR] Sala no encontrada."); return; }
    
    // Actualizar asientos de la sala según la fecha
    modelo->actualizarAsientosEnSala(salaSeleccionada, fecha);
    
    // gestionar asientos
    ListaDobleCircular<Asiento*> seleccion;
    double total = 0.0;
    bool confirmado = gestionarAsientos(seleccion, salaSeleccionada, total);
    if (!confirmado) { vista->mostrarMensaje("[INFO] Reserva cancelada o regreso."); liberarAsientosTemporales(seleccion); return; }
    if (seleccion.getSize() == 0) { vista->mostrarMensaje("[ERROR] No selecciono asientos."); liberarAsientosTemporales(seleccion); return; }
    
    // ocupar permanentemente
    Nodo<Asiento*>* ca = seleccion.getHead();
    if (ca) {
        Nodo<Asiento*>* inicioA = ca;
        do { ca->data->ocupar(); ca = ca->next; } while (ca != inicioA);
    }
    
    // crear reserva y guardar (pasar la fecha)
    Reserva* r = new Reserva(usuario, funcionSeleccionada, seleccion, total, fecha);
    modelo->agregarReserva(r);
    
    // mostrar informe completo (por salas y peliculas)
    vista->mostrarMensaje("\n=== INFORME DE LA RESERVA ===");
    vista->mostrarMensaje("Cliente: " + usuario->getNombre() + " | Cedula: " + usuario->getCedula());
    vista->mostrarMensaje("Pelicula: " + peliculaSeleccionada->getNombre());
    vista->mostrarMensaje("Horario: " + funcionSeleccionada->getHorario());
    vista->mostrarMensaje("Sala: " + std::to_string(funcionSeleccionada->getSalaId()));
    vista->mostrarMensaje("Asientos reservados: " + std::to_string(r->getAsientos().getSize()));
    vista->mostrarMensaje("Total pagado: $" + std::to_string(r->getTotal()));
    
    // mostrar estado por sala
    Nodo<Sala*>* salaIt = modelo->getSalas().getHead();
    if (salaIt) {
        Nodo<Sala*>* inicioS = salaIt;
        do {
            vista->mostrarMensaje("\nSala #" + std::to_string(salaIt->data->getId()));
            vista->mostrarMensaje("Ocupados: " + std::to_string(salaIt->data->contarAsientosOcupados()));
            vista->mostrarMensaje("Disponibles: " + std::to_string(salaIt->data->contarAsientosDisponibles()));
            salaIt = salaIt->next;
        } while (salaIt != inicioS);
    }
    
    // guardar o cancelar (volver al menu)
    vista->mostrarMensaje("\n1. Guardar y regresar al menu principal");
    vista->mostrarMensaje("2. Cancelar (liberar y regresar al menu principal)");
    int opc = vista->leerIntEnRango("Seleccione: ", 1, 2);
    if (opc == 2) {
        // liberar asientos (ya ocupados en modelo? si ocupamos, hay que liberar)
        Nodo<Asiento*>* curRel = r->getAsientos().getHead();
        if (curRel) {
            Nodo<Asiento*>* inicioRel = curRel;
            do { curRel->data->liberar(); curRel = curRel->next; } while (curRel != inicioRel);
        }
        modelo->eliminarReserva(r);
        vista->mostrarMensaje("[INFO] Reserva cancelada y datos no guardados.");
    } else {
        vista->mostrarMensaje("[EXITO] Reserva guardada. Regresando al menu principal.");
    }
}
// gestionarAsientos e inserciones/eliminaciones mantienen validaciones y permiten tokens múltiples
bool Controlador::gestionarAsientos(ListaDobleCircular<Asiento*>& asientosSeleccionados, 
                                    Sala* sala, double& total) {
    int opcion;
    while (true) {
        sala->mostrarAsientos();
        imprimirResumenAsientos(asientosSeleccionados, total);
        vista->mostrarMenuAsientos();
        opcion = vista->leerIntEnRango("\nSeleccione una opcion: ", 1, 7);
        switch (opcion) {
        case 1: insertarMultiplesAsientos(asientosSeleccionados, sala, total); break;
        case 2: eliminarMultiplesAsientos(asientosSeleccionados, total); break;
        case 3: buscarAsiento(asientosSeleccionados); break;
        case 4: imprimirAsientosSeleccionados(asientosSeleccionados); break;
        case 5: {
            if (asientosSeleccionados.getSize() == 0) { vista->mostrarMensaje("[ERROR] Debe seleccionar al menos un asiento."); break; }
            std::string conf = vista->leerString("Confirmar reserva? (s/n): ");
            std::string cm = convertirAMinusculas(conf);
            if (cm == "s" || cm == "si") return true;
            break;
        }
        case 6: {
            std::string conf = vista->leerString("Cancelar reserva y liberar asientos? (s/n): ");
            std::string cm = convertirAMinusculas(conf);
            if (cm == "s" || cm == "si") { liberarAsientosTemporales(asientosSeleccionados); return false; }
            break;
        }
        case 7:
            liberarAsientosTemporales(asientosSeleccionados);
            return false;
        default: break;
        }
    }
    return false;
}

void Controlador::insertarMultiplesAsientos(ListaDobleCircular<Asiento*>& asientosSeleccionados, 
                                            Sala* sala, double& total) {
    vista->mostrarMensaje("\n=== INSERTAR ASIENTOS (puede ingresar multiples separados por espacios) ===");
    std::string linea = vista->leerString("Asientos (ej A1 B2 C3) o '0' para regresar: ");
    if (linea == "0") return;
    std::stringstream ss(linea);
    std::string token;
    int exitosos=0, fallidos=0;
    while (ss >> token) {
        // normalizar a mayusculas
        for (char &c : token) c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
        if (token.size() < 2) { vista->mostrarMensaje("[ERROR] Formato invalido: " + token); fallidos++; continue; }
        Asiento* a = sala->buscarAsientoPorId(token);
        if (!a) { vista->mostrarMensaje("[ERROR] No existe: " + token); fallidos++; continue; }
        if (a->isOcupado()) { vista->mostrarMensaje("[ERROR] Ocupado: " + token); fallidos++; continue; }
        // ya seleccionado?
        bool ya=false;
        Nodo<Asiento*>* cur = asientosSeleccionados.getHead();
        if (cur) { Nodo<Asiento*>* inicio=cur; do { if (cur->data->getId()==token){ ya=true; break; } cur=cur->next; } while(cur!=inicio); }
        if (ya) { vista->mostrarMensaje("[ERROR] Ya seleccionado: " + token); fallidos++; continue; }
        a->reservarTemporal();
        asientosSeleccionados.insertarCola(a);
        total += a->getPrecio();
        vista->mostrarMensaje("[OK] " + token + " agregado (" + a->getTipo() + " $" + std::to_string(a->getPrecio()) + ")");
        exitosos++;
    }
    vista->mostrarMensaje("Resumen: Exitosos=" + std::to_string(exitosos) + " Fallidos=" + std::to_string(fallidos));
}

void Controlador::eliminarMultiplesAsientos(ListaDobleCircular<Asiento*>& asientosSeleccionados, double& total) {
    if (asientosSeleccionados.getSize() == 0) { vista->mostrarMensaje("[INFO] No hay asientos seleccionados."); return; }
    imprimirAsientosSeleccionados(asientosSeleccionados);
    std::string linea = vista->leerString("Asientos a eliminar (ej A1 B2) o '0' para regresar: ");
    if (linea == "0") return;
    std::stringstream ss(linea);
    std::string token;
    int eliminados=0, noenc=0;
    while (ss >> token) {
        for (char &c : token) c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
        Nodo<Asiento*>* cur = asientosSeleccionados.getHead();
        if (!cur) { noenc++; continue; }
        Nodo<Asiento*>* inicio = cur;
        bool encontrado=false;
        do {
            if (cur->data->getId() == token) {
                encontrado=true;
                double precio = cur->data->getPrecio();
                cur->data->liberarTemporal(); // vuelve a estado disponible
                asientosSeleccionados.eliminarNodo(cur);
                total -= precio;
                vista->mostrarMensaje("[OK] " + token + " eliminado (-$" + std::to_string(precio) + ")");
                eliminados++;
                break;
            }
            cur = cur->next;
        } while (cur != inicio);
        if (!encontrado) { vista->mostrarMensaje("[ERROR] No en seleccion: " + token); noenc++; }
    }
    vista->mostrarMensaje("Resumen: Eliminados=" + std::to_string(eliminados) + " NoEncontrados=" + std::to_string(noenc));
}

void Controlador::buscarAsiento(ListaDobleCircular<Asiento*>& asientosSeleccionados) {
    if (asientosSeleccionados.getSize() == 0) {
        vista->mostrarMensaje("\n[INFO] No hay asientos seleccionados.");
        return;
    }
    
    std::string idAsiento = vista->leerString("\nIngrese ID del asiento a buscar: ");
    
    for (char& c : idAsiento) {
        c = toupper(c);
    }
    
    Nodo<Asiento*>* current = asientosSeleccionados.getHead();
    bool encontrado = false;
    
    if (current != nullptr) {
        do {
            if (current->data->getId() == idAsiento) {
                vista->mostrarMensaje("\n[ENCONTRADO] Asiento: " + current->data->getId());
                vista->mostrarMensaje("  Tipo: " + current->data->getTipo());
                vista->mostrarMensaje("  Fila: " + std::to_string(current->data->getFila()));
                vista->mostrarMensaje("  Columna: " + std::to_string(current->data->getColumna()));
                vista->mostrarMensaje("  Precio: $" + std::to_string(current->data->getPrecio()));
                encontrado = true;
                break;
            }
            current = current->next;
        } while (current != asientosSeleccionados.getHead());
    }
    
    if (!encontrado) {
        vista->mostrarMensaje("\n[NO ENCONTRADO] El asiento " + idAsiento + " no esta en tu seleccion.");
    }
}

void Controlador::imprimirAsientosSeleccionados(ListaDobleCircular<Asiento*>& asientosSeleccionados) {
    if (asientosSeleccionados.getSize() == 0) {
        vista->mostrarMensaje("\n[INFO] No hay asientos seleccionados actualmente.");
        return;
    }
    
    vista->mostrarMensaje("\n========== ASIENTOS SELECCIONADOS ==========");
    Nodo<Asiento*>* current = asientosSeleccionados.getHead();
    double subtotal = 0.0;
    int numVIP = 0;
    int numGeneral = 0;
    
    if (current != nullptr) {
        do {
            std::cout << "  " << current->data->getId() 
                     << " - " << current->data->getTipo() 
                     << " (Fila " << current->data->getFila() 
                     << ", Col " << current->data->getColumna() << ") - $" 
                     << std::fixed << std::setprecision(2) << current->data->getPrecio() << std::endl;
            subtotal += current->data->getPrecio();
            if (current->data->getTipo() == "VIP") numVIP++;
            else numGeneral++;
            current = current->next;
        } while (current != asientosSeleccionados.getHead());
    }
    
    vista->mostrarMensaje("============================================");
    vista->mostrarMensaje("Total asientos: " + std::to_string(asientosSeleccionados.getSize()) +
                         " (VIP: " + std::to_string(numVIP) + ", General: " + std::to_string(numGeneral) + ")");
    std::cout << "SUBTOTAL: $" << std::fixed << std::setprecision(2) << subtotal << std::endl;
    vista->mostrarMensaje("============================================");
}

void Controlador::imprimirResumenAsientos(ListaDobleCircular<Asiento*>& asientosSeleccionados, double total) {
    std::cout << "\n[SELECCION ACTUAL: " << asientosSeleccionados.getSize() << " asientos | Total: $" 
              << std::fixed << std::setprecision(2) << total << "]" << std::endl;
}

void Controlador::liberarAsientosTemporales(ListaDobleCircular<Asiento*>& asientosSeleccionados) {
    Nodo<Asiento*>* current = asientosSeleccionados.getHead();
    if (current != nullptr) {
        do {
            current->data->liberarTemporal();
            current = current->next;
        } while (current != asientosSeleccionados.getHead());
    }
}

void Controlador::cancelarReserva() {
    vista->mostrarMensaje("\n=== CANCELAR RESERVA ===");
    
    if (modelo->getReservas().getSize() == 0) {
        vista->mostrarMensaje("[INFO] No hay reservas registradas.");
        return;
    }
    
    // Usar TOON como snapshot para listar reservas y seleccionar
    vista->mostrarMensaje("\nReservas actuales:");
    toon::TOON reservasToon = toon::TOON::array();
    Nodo<Reserva*>* curRes = modelo->getReservas().getHead();
    if (curRes) {
        Nodo<Reserva*>* inicio = curRes;
        do { reservasToon.push_back(curRes->data->toToon()); curRes = curRes->next; } while (curRes != inicio);
    }

    // Mostrar snapshot usando TOON
    toon::TOONNode* nodo = reservasToon.array_head;
    int idx = 1;
    while (nodo != nullptr) {
        const toon::TOON* r = nodo->value;
        std::string nombre = "";
        std::string ced = "";
        std::string horario = "";
        int salaId = 0;
        double total = 0.0;
        const toon::TOON* u = r->get("usuario");
        if (u) { const toon::TOON* n = u->get("nombre"); const toon::TOON* c = u->get("cedula"); if (n) nombre = n->string_value; if (c) ced = c->string_value; }
        const toon::TOON* fId = r->get("funcionId"); if (fId) salaId = static_cast<int>(fId->number_value);
        const toon::TOON* hr = r->get("horario"); if (hr) horario = hr->string_value;
        const toon::TOON* tot = r->get("total"); if (tot) total = tot->number_value;
        std::cout << idx << ". Cliente: " << nombre << " | Cedula: " << ced << " | Horario: " << horario << " | Sala: " << salaId << " | Total: $" << std::fixed << std::setprecision(2) << total << std::endl;
        nodo = nodo->next; idx++;
    }
    vista->mostrarMensaje("0. Regresar");

    int opcion = vista->leerIntEnRango("\nSeleccione el numero de reserva a cancelar: ", 0, reservasToon.size());
    if (opcion == 0) return;

    // localizar el nodo TOON seleccionado
    toon::TOONNode* sel = reservasToon.array_head;
    for (int i=1;i<opcion;i++) sel = sel->next;
    const toon::TOON* selT = sel->value;

    // buscar la reserva real en modelo comparando campos claves (cedula, horario, sala, fecha, total)
    std::string selCed = ""; if (selT->get("usuario") && selT->get("usuario")->get("cedula")) selCed = selT->get("usuario")->get("cedula")->string_value;
    std::string selHorario = selT->get("horario") ? selT->get("horario")->string_value : "";
    int selSalaId = selT->get("funcionId") ? static_cast<int>(selT->get("funcionId")->number_value) : 0;
    std::string selFecha = selT->get("fecha") ? selT->get("fecha")->string_value : "";
    double selTotal = selT->get("total") ? selT->get("total")->number_value : 0.0;

    Nodo<Reserva*>* current = modelo->getReservas().getHead();
    Reserva* reservaACancelar = nullptr;
    if (current) {
        Nodo<Reserva*>* inicio = current;
        do {
            Reserva* cand = current->data;
            if (cand->getUsuario()->getCedula() == selCed && cand->getFuncion()->getHorario() == selHorario && cand->getFuncion()->getSalaId() == selSalaId && cand->getFecha() == selFecha && fabs(cand->getTotal() - selTotal) < 0.01) {
                reservaACancelar = cand; break;
            }
            current = current->next;
        } while (current != inicio);
    }

    if (!reservaACancelar) {
        vista->mostrarMensaje("\n[ERROR] No se encontro la reserva seleccionada en el modelo.");
        return;
    }
    
    vista->mostrarMensaje("\n--- DETALLES DE LA RESERVA ---");
    vista->mostrarMensaje("Cliente: " + reservaACancelar->getUsuario()->getNombre());
    vista->mostrarMensaje("Pelicula: " + reservaACancelar->getFuncion()->getPelicula()->getNombre());
    vista->mostrarMensaje("Asientos: " + std::to_string(reservaACancelar->getAsientos().getSize()));
    
    std::string confirmar = vista->leerString("\nEsta seguro de cancelar esta reserva? (s/n): ");
    
    if (confirmar == "s" || confirmar == "S") {
        modelo->eliminarReserva(reservaACancelar);
        vista->mostrarMensaje("\n[EXITO] Reserva cancelada correctamente.");
        vista->mostrarMensaje("Los asientos han sido liberados.");
    } else {
        vista->mostrarMensaje("\n[INFO] Cancelacion abortada.");
    }
}

void Controlador::verReporte() {
    vista->mostrarMensaje("\n========================================");
    vista->mostrarMensaje("         REPORTE GENERAL DEL CINE      ");
    vista->mostrarMensaje("========================================");
    vista->mostrarMensaje("Fecha: " + obtenerFechaActual());
    vista->mostrarMensaje("Hora: " + obtenerHoraActual());
    vista->mostrarMensaje("========================================\n");
    
    // Estadisticas generales
    vista->mostrarMensaje("--- ESTADISTICAS GENERALES ---");
    vista->mostrarMensaje("Clientes registrados: " + std::to_string(modelo->getUsuarios().getSize()));
    vista->mostrarMensaje("Reservas activas: " + std::to_string(modelo->getReservas().getSize()));
    
    // Calcular ingresos totales y asientos vendidos
    double ingresosTotales = 0.0;
    int asientosVendidos = 0;
    Nodo<Reserva*>* currentRes = modelo->getReservas().getHead();
    if (currentRes != nullptr) {
        do {
            ingresosTotales += currentRes->data->getTotal();
            asientosVendidos += currentRes->data->getAsientos().getSize();
            currentRes = currentRes->next;
        } while (currentRes != modelo->getReservas().getHead());
    }
    std::cout << "Asientos vendidos: " << asientosVendidos << std::endl;
    std::cout << "Ingresos totales: $" << std::fixed << std::setprecision(2) << ingresosTotales << std::endl;
    
    // Recopilar fechas unicas de reservas usando `toon`
    toon::TOON fechas = toon::TOON::array();
    currentRes = modelo->getReservas().getHead();
    if (currentRes != nullptr) {
        do {
            std::string fecha = currentRes->data->getFecha();
            bool existe = false;
            // Iterar array interno de `fechas` para comprobar existencia
            toon::TOONNode* nodo = fechas.array_head;
            while (nodo != nullptr) {
                if (nodo->value && nodo->value->type == toon::TOON::STRING && nodo->value->string_value == fecha) { existe = true; break; }
                nodo = nodo->next;
            }
            if (!existe && !fecha.empty()) {
                fechas.push_back(toon::TOON(fecha));
            }
            currentRes = currentRes->next;
        } while (currentRes != modelo->getReservas().getHead());
    }

    // Mostrar reservas agrupadas por fecha
    if (fechas.size() == 0) {
        vista->mostrarMensaje("\n--- RESERVAS POR FECHA ---");
        vista->mostrarMensaje("No hay reservas registradas.");
    } else {
        vista->mostrarMensaje("\n--- RESERVAS POR FECHA ---\n");

        // Iterar fechas desde la estructura TOON
        toon::TOONNode* fechaNodo = fechas.array_head;
        while (fechaNodo != nullptr) {
            std::string fecha = "";
            if (fechaNodo->value && fechaNodo->value->type == toon::TOON::STRING) fecha = fechaNodo->value->string_value;
            vista->mostrarMensaje("\n=== FECHA: " + fecha + " ===");
            int numReserva = 1;
            int reservasEnFecha = 0;
            double ingresosPorFecha = 0.0;

            currentRes = modelo->getReservas().getHead();
            if (currentRes != nullptr) {
                do {
                    if (currentRes->data->getFecha() == fecha) {
                        reservasEnFecha++;
                        Usuario* cliente = currentRes->data->getUsuario();
                        Funcion* funcion = currentRes->data->getFuncion();
                        Sala* sala = nullptr;

                        Nodo<Sala*>* salaNodo = modelo->getSalas().getHead();
                        if (salaNodo != nullptr) {
                            do {
                                if (salaNodo->data->getId() == funcion->getSalaId()) {
                                    sala = salaNodo->data;
                                    break;
                                }
                                salaNodo = salaNodo->next;
                            } while (salaNodo != modelo->getSalas().getHead());
                        }

                        std::cout << "\n  Reserva " << numReserva << ":" << std::endl;
                        std::cout << "    Usuario: " << cliente->getNombre() << std::endl;
                        std::cout << "    Cedula: " << cliente->getCedula() << std::endl;
                        std::cout << "    Pelicula: " << funcion->getPelicula()->getNombre() << std::endl;
                        std::cout << "    Horario: " << funcion->getHorario() << std::endl;
                        std::cout << "    Sala: " << funcion->getSalaId() << std::endl;
                        std::cout << "    Cantidad de asientos: " << currentRes->data->getAsientos().getSize() << std::endl;

                        std::cout << "    Asientos: ";
                        Nodo<Asiento*>* asiento = currentRes->data->getAsientos().getHead();
                        if (asiento != nullptr) {
                            do {
                                std::cout << asiento->data->getId() << " ";
                                asiento = asiento->next;
                            } while (asiento != currentRes->data->getAsientos().getHead());
                        }
                        std::cout << std::endl;

                        std::cout << "    Total pagado: $" << std::fixed << std::setprecision(2) 
                                 << currentRes->data->getTotal() << std::endl;

                        ingresosPorFecha += currentRes->data->getTotal();
                        numReserva++;
                    }
                    currentRes = currentRes->next;
                } while (currentRes != modelo->getReservas().getHead());
            }

            std::cout << "\n  Resumen de " << fecha << ":" << std::endl;
            std::cout << "    Total de reservas: " << reservasEnFecha << std::endl;
            std::cout << "    Ingresos totales: $" << std::fixed << std::setprecision(2) 
                     << ingresosPorFecha << std::endl;

            fechaNodo = fechaNodo->next;
        }
    }
    
    vista->mostrarMensaje("\n========================================");
    vista->mostrarMensaje("         FIN DEL REPORTE               ");
    vista->mostrarMensaje("========================================\n");
}

std::string Controlador::obtenerFechaActual() {
    time_t now = time(0);
    tm* ltm = localtime(&now);
    
    std::stringstream ss;
    ss << std::setfill('0') << std::setw(2) << ltm->tm_mday << "/"
       << std::setfill('0') << std::setw(2) << (1 + ltm->tm_mon) << "/"
       << (1900 + ltm->tm_year);
    
    return ss.str();
}

std::string Controlador::obtenerHoraActual() {
    time_t now = time(0);
    tm* ltm = localtime(&now);
    
    std::stringstream ss;
    ss << std::setfill('0') << std::setw(2) << ltm->tm_hour << ":"
       << std::setfill('0') << std::setw(2) << ltm->tm_min << ":"
       << std::setfill('0') << std::setw(2) << ltm->tm_sec;
    
    return ss.str();
}

void Controlador::menuOrdenamiento() {
    int opcion;
    do {
        vista->mostrarMenuOrdenamiento();
        opcion = vista->leerIntEnRango("Seleccione una opcion: ", 0, 3);
        
        switch (opcion) {
        case 1:
            ordenarUsuarios();
            break;
        case 2:
            ordenarReservas();
            break;
        case 3:
            ordenarAsientos();
            break;
        case 0:
            vista->mostrarMensaje("\n[INFO] Regresando al menu principal...");
            break;
        default:
            break;
        }
    } while (opcion != 0);
}

void Controlador::ordenarUsuarios() {
    if (modelo->getUsuarios().getSize() == 0) {
        vista->mostrarMensaje("\n[INFO] No hay usuarios registrados para ordenar.");
        return;
    }
    
    vista->mostrarMensaje("\n=== ORDENAR USUARIOS ===");
    vista->mostrarMenuCriteriosUsuarios();
    
    int criterio = vista->leerIntEnRango("Seleccione criterio: ", 0, 3);
    if (criterio == 0) return;
    
    vista->mostrarMenuAlgoritmos();
    int algoritmo = vista->leerIntEnRango("Seleccione algoritmo: ", 0, 8);
    if (algoritmo == 0) return;
    
    // Definir comparador según criterio - CORREGIDO
    std::function<bool(Usuario*, Usuario*)> comparador;
    std::function<double(Usuario*)> extractorValor;
    std::function<int(Usuario*)> extractorEntero;
    
    switch (criterio) {
        case 1: // Por Nombre (A-Z) - Case insensitive CORREGIDO
            comparador = [](Usuario* a, Usuario* b) {
                std::string nombreA = a->getNombre();
                std::string nombreB = b->getNombre();
                // Convertir a minúsculas para comparación
                std::transform(nombreA.begin(), nombreA.end(), nombreA.begin(), 
                              [](unsigned char c){ return std::tolower(c); });
                std::transform(nombreB.begin(), nombreB.end(), nombreB.begin(), 
                              [](unsigned char c){ return std::tolower(c); });
                return nombreA < nombreB;
            };
            extractorValor = [](Usuario* u) {
                std::string nombre = u->getNombre();
                if (nombre.empty()) return 0.0;
                return static_cast<double>(std::tolower(static_cast<unsigned char>(nombre[0])));
            };
            extractorEntero = [](Usuario* u) {
                std::string nombre = u->getNombre();
                if (nombre.empty()) return 0;
                return static_cast<int>(std::tolower(static_cast<unsigned char>(nombre[0])));
            };
            break;
        case 2: // Por Cédula
            comparador = [](Usuario* a, Usuario* b) {
                return a->getCedula() < b->getCedula();
            };
            extractorValor = [](Usuario* u) {
                try {
                    return std::stod(u->getCedula());
                } catch (...) {
                    return 0.0;
                }
            };
            extractorEntero = [](Usuario* u) {
                try {
                    return std::stoi(u->getCedula());
                } catch (...) {
                    return 0;
                }
            };
            break;
        case 3: // Por Edad
            comparador = [](Usuario* a, Usuario* b) {
                return a->getEdad() < b->getEdad();
            };
            extractorValor = [](Usuario* u) {
                return static_cast<double>(u->getEdad());
            };
            extractorEntero = [](Usuario* u) {
                return u->getEdad();
            };
            break;
    }
    
    // Ejecutar algoritmo seleccionado
    vista->mostrarMensaje("\n[INFO] Ordenando usuarios...");
    auto inicio = std::chrono::high_resolution_clock::now();
    
    switch (algoritmo) {
        case 1:
            AlgoritmosOrdenamiento<Usuario*>::bubbleSort(modelo->getUsuarios(), comparador);
            vista->mostrarMensaje("[EXITO] Usuarios ordenados con Bubble Sort");
            break;
        case 2:
            AlgoritmosOrdenamiento<Usuario*>::selectionSort(modelo->getUsuarios(), comparador);
            vista->mostrarMensaje("[EXITO] Usuarios ordenados con Selection Sort");
            break;
        case 3:
            AlgoritmosOrdenamiento<Usuario*>::insertionSort(modelo->getUsuarios(), comparador);
            vista->mostrarMensaje("[EXITO] Usuarios ordenados con Insertion Sort");
            break;
        case 4:
            AlgoritmosOrdenamiento<Usuario*>::mergeSort(modelo->getUsuarios(), comparador);
            vista->mostrarMensaje("[EXITO] Usuarios ordenados con Merge Sort");
            break;
        case 5:
            AlgoritmosOrdenamiento<Usuario*>::quickSort(modelo->getUsuarios(), comparador);
            vista->mostrarMensaje("[EXITO] Usuarios ordenados con Quick Sort");
            break;
        case 6:
            AlgoritmosOrdenamiento<Usuario*>::bucketSort(modelo->getUsuarios(), extractorValor, comparador);
            vista->mostrarMensaje("[EXITO] Usuarios ordenados con Bucket Sort");
            break;
        case 7:
            if (criterio == 1) {
                vista->mostrarMensaje("[ADVERTENCIA] Radix Sort no es optimo para nombres. Usando Quick Sort...");
                AlgoritmosOrdenamiento<Usuario*>::quickSort(modelo->getUsuarios(), comparador);
            } else {
                AlgoritmosOrdenamiento<Usuario*>::radixSort(modelo->getUsuarios(), extractorEntero);
                vista->mostrarMensaje("[EXITO] Usuarios ordenados con Radix Sort");
            }
            break;
        case 8:
            if (criterio == 3) {
                AlgoritmosOrdenamiento<Usuario*>::countingSort(modelo->getUsuarios(), extractorEntero, 120);
                vista->mostrarMensaje("[EXITO] Usuarios ordenados con Counting Sort");
            } else {
                vista->mostrarMensaje("[ADVERTENCIA] Counting Sort solo funciona bien con edad. Usando Quick Sort...");
                AlgoritmosOrdenamiento<Usuario*>::quickSort(modelo->getUsuarios(), comparador);
            }
            break;
    }
    
    auto fin = std::chrono::high_resolution_clock::now();
    auto duracion = std::chrono::duration_cast<std::chrono::microseconds>(fin - inicio);
    
    std::cout << "Tiempo de ejecucion: " << duracion.count() << " microsegundos" << std::endl;
    
    // Mostrar usuarios ordenados
    vista->mostrarMensaje("\n--- USUARIOS ORDENADOS ---");
    Nodo<Usuario*>* current = modelo->getUsuarios().getHead();
    if (current) {
        Nodo<Usuario*>* inicio = current;
        int idx = 1;
        do {
            std::cout << idx << ". " << current->data->getNombre() 
                     << " | Cedula: " << current->data->getCedula()
                     << " | Edad: " << current->data->getEdad() << std::endl;
            current = current->next;
            idx++;
        } while (current != inicio);
    }
    
    modelo->guardarUsuarios();
}

// ============================================================================
// REEMPLAZAR SOLO LOS COMPARADORES EN ordenarReservas()
// ============================================================================

void Controlador::ordenarReservas() {
    if (modelo->getReservas().getSize() == 0) {
        vista->mostrarMensaje("\n[INFO] No hay reservas registradas para ordenar.");
        return;
    }
    
    vista->mostrarMensaje("\n=== ORDENAR RESERVAS ===");
    vista->mostrarMenuCriteriosReservas();
    
    int criterio = vista->leerIntEnRango("Seleccione criterio: ", 0, 4);
    if (criterio == 0) return;
    
    vista->mostrarMenuAlgoritmos();
    int algoritmo = vista->leerIntEnRango("Seleccione algoritmo: ", 0, 8);
    if (algoritmo == 0) return;
    
    // Definir comparadores - CORREGIDO
    std::function<bool(Reserva*, Reserva*)> comparador;
    std::function<double(Reserva*)> extractorValor;
    std::function<int(Reserva*)> extractorEntero;
    
    switch (criterio) {
        case 1: // Por Fecha (más reciente primero) - CORREGIDO
            comparador = [](Reserva* a, Reserva* b) {
                std::string fechaA = a->getFecha();
                std::string fechaB = b->getFecha();
                
                // Convertir DD/MM/YYYY a YYYYMMDD para comparación
                if (fechaA.length() >= 10 && fechaB.length() >= 10) {
                    int diaA = std::stoi(fechaA.substr(0, 2));
                    int mesA = std::stoi(fechaA.substr(3, 2));
                    int anioA = std::stoi(fechaA.substr(6, 4));
                    int valorA = anioA * 10000 + mesA * 100 + diaA;
                    
                    int diaB = std::stoi(fechaB.substr(0, 2));
                    int mesB = std::stoi(fechaB.substr(3, 2));
                    int anioB = std::stoi(fechaB.substr(6, 4));
                    int valorB = anioB * 10000 + mesB * 100 + diaB;
                    
                    return valorA > valorB; // Más reciente primero (descendente)
                }
                return fechaA > fechaB;
            };
            extractorValor = [](Reserva* r) {
                std::string fecha = r->getFecha();
                if (fecha.length() >= 10) {
                    int dia = std::stoi(fecha.substr(0, 2));
                    int mes = std::stoi(fecha.substr(3, 2));
                    int anio = std::stoi(fecha.substr(6, 4));
                    return static_cast<double>(anio * 10000 + mes * 100 + dia);
                }
                return 0.0;
            };
            extractorEntero = [](Reserva* r) {
                std::string fecha = r->getFecha();
                if (fecha.length() >= 10) {
                    int dia = std::stoi(fecha.substr(0, 2));
                    int mes = std::stoi(fecha.substr(3, 2));
                    int anio = std::stoi(fecha.substr(6, 4));
                    return anio * 10000 + mes * 100 + dia;
                }
                return 0;
            };
            break;
        case 2: // Por Total
            comparador = [](Reserva* a, Reserva* b) {
                return a->getTotal() < b->getTotal();
            };
            extractorValor = [](Reserva* r) {
                return r->getTotal();
            };
            extractorEntero = [](Reserva* r) {
                return static_cast<int>(r->getTotal());
            };
            break;
        case 3: // Por Nombre Cliente (A-Z) - Case insensitive CORREGIDO
            comparador = [](Reserva* a, Reserva* b) {
                std::string nombreA = a->getUsuario()->getNombre();
                std::string nombreB = b->getUsuario()->getNombre();
                std::transform(nombreA.begin(), nombreA.end(), nombreA.begin(), 
                              [](unsigned char c){ return std::tolower(c); });
                std::transform(nombreB.begin(), nombreB.end(), nombreB.begin(), 
                              [](unsigned char c){ return std::tolower(c); });
                return nombreA < nombreB;
            };
            extractorValor = [](Reserva* r) {
                std::string nombre = r->getUsuario()->getNombre();
                if (nombre.empty()) return 0.0;
                return static_cast<double>(std::tolower(static_cast<unsigned char>(nombre[0])));
            };
            extractorEntero = [](Reserva* r) {
                std::string nombre = r->getUsuario()->getNombre();
                if (nombre.empty()) return 0;
                return static_cast<int>(std::tolower(static_cast<unsigned char>(nombre[0])));
            };
            break;
        case 4: // Por Número de Asientos
            comparador = [](Reserva* a, Reserva* b) {
                return a->getAsientos().getSize() < b->getAsientos().getSize();
            };
            extractorValor = [](Reserva* r) {
                return static_cast<double>(r->getAsientos().getSize());
            };
            extractorEntero = [](Reserva* r) {
                return r->getAsientos().getSize();
            };
            break;
    }
    
    // Ejecutar algoritmo
    vista->mostrarMensaje("\n[INFO] Ordenando reservas...");
    auto inicio = std::chrono::high_resolution_clock::now();
    
    switch (algoritmo) {
        case 1:
            AlgoritmosOrdenamiento<Reserva*>::bubbleSort(modelo->getReservas(), comparador);
            vista->mostrarMensaje("[EXITO] Reservas ordenadas con Bubble Sort");
            break;
        case 2:
            AlgoritmosOrdenamiento<Reserva*>::selectionSort(modelo->getReservas(), comparador);
            vista->mostrarMensaje("[EXITO] Reservas ordenadas con Selection Sort");
            break;
        case 3:
            AlgoritmosOrdenamiento<Reserva*>::insertionSort(modelo->getReservas(), comparador);
            vista->mostrarMensaje("[EXITO] Reservas ordenadas con Insertion Sort");
            break;
        case 4:
            AlgoritmosOrdenamiento<Reserva*>::mergeSort(modelo->getReservas(), comparador);
            vista->mostrarMensaje("[EXITO] Reservas ordenadas con Merge Sort");
            break;
        case 5:
            AlgoritmosOrdenamiento<Reserva*>::quickSort(modelo->getReservas(), comparador);
            vista->mostrarMensaje("[EXITO] Reservas ordenadas con Quick Sort");
            break;
        case 6:
            AlgoritmosOrdenamiento<Reserva*>::bucketSort(modelo->getReservas(), extractorValor, comparador);
            vista->mostrarMensaje("[EXITO] Reservas ordenadas con Bucket Sort");
            break;
        case 7:
            if (criterio == 3) {
                vista->mostrarMensaje("[ADVERTENCIA] Radix Sort no es optimo para nombres. Usando Quick Sort...");
                AlgoritmosOrdenamiento<Reserva*>::quickSort(modelo->getReservas(), comparador);
            } else {
                AlgoritmosOrdenamiento<Reserva*>::radixSort(modelo->getReservas(), extractorEntero);
                vista->mostrarMensaje("[EXITO] Reservas ordenadas con Radix Sort");
            }
            break;
        case 8:
            if (criterio == 4) {
                AlgoritmosOrdenamiento<Reserva*>::countingSort(modelo->getReservas(), extractorEntero, 30);
                vista->mostrarMensaje("[EXITO] Reservas ordenadas con Counting Sort");
            } else {
                vista->mostrarMensaje("[ADVERTENCIA] Counting Sort limitado a este criterio. Usando Quick Sort...");
                AlgoritmosOrdenamiento<Reserva*>::quickSort(modelo->getReservas(), comparador);
            }
            break;
    }
    
    auto fin = std::chrono::high_resolution_clock::now();
    auto duracion = std::chrono::duration_cast<std::chrono::microseconds>(fin - inicio);
    
    std::cout << "Tiempo de ejecucion: " << duracion.count() << " microsegundos" << std::endl;
    
    // Mostrar reservas ordenadas
    vista->mostrarMensaje("\n--- RESERVAS ORDENADAS ---");
    Nodo<Reserva*>* current = modelo->getReservas().getHead();
    if (current) {
        Nodo<Reserva*>* inicio = current;
        int idx = 1;
        do {
            std::cout << idx << ". Cliente: " << current->data->getUsuario()->getNombre()
                     << " | Fecha: " << current->data->getFecha()
                     << " | Asientos: " << current->data->getAsientos().getSize()
                     << " | Total: $" << std::fixed << std::setprecision(2) 
                     << current->data->getTotal() << std::endl;
            current = current->next;
            idx++;
        } while (current != inicio);
    }
    
    modelo->guardarReservas();
}

void Controlador::ordenarAsientos() {
    if (modelo->getSalas().getSize() == 0) {
        vista->mostrarMensaje("\n[ERROR] No hay salas disponibles.");
        return;
    }
    
    vista->mostrarMensaje("\n=== ORDENAR ASIENTOS DE UNA SALA ===");
    vista->mostrarMensaje("\nSalas disponibles:");
    
    Nodo<Sala*>* current = modelo->getSalas().getHead();
    Nodo<Sala*>* inicio = current;
    int numSalas = 0;
    do {
        numSalas++;
        std::cout << numSalas << ". Sala " << current->data->getId() 
                 << " (" << current->data->getAsientos().getSize() << " asientos)" << std::endl;
        current = current->next;
    } while (current != inicio);
    
    vista->mostrarMensaje("0. Regresar");
    
    int salaSeleccion = vista->leerIntEnRango("Seleccione sala: ", 0, numSalas);
    if (salaSeleccion == 0) return;
    
    // Obtener sala seleccionada
    current = modelo->getSalas().getHead();
    for (int i = 1; i < salaSeleccion; i++) {
        current = current->next;
    }
    Sala* salaSeleccionada = current->data;
    
    vista->mostrarMenuCriteriosAsientos();
    
    int criterio = vista->leerIntEnRango("Seleccione criterio: ", 0, 4);
    if (criterio == 0) return;
    
    vista->mostrarMenuAlgoritmos();
    int algoritmo = vista->leerIntEnRango("Seleccione algoritmo: ", 0, 8);
    if (algoritmo == 0) return;
    
    // Definir comparadores
    std::function<bool(Asiento*, Asiento*)> comparador;
    std::function<double(Asiento*)> extractorValor;
    std::function<int(Asiento*)> extractorEntero;
    
    switch (criterio) {
        case 1: // Por ID
            comparador = [](Asiento* a, Asiento* b) {
                return a->getId() < b->getId();
            };
            extractorValor = [](Asiento* a) {
                return a->getFila() * 10.0 + a->getColumna();
            };
            extractorEntero = [](Asiento* a) {
                return a->getFila() * 10 + a->getColumna();
            };
            break;
        case 2: // Por Precio
            comparador = [](Asiento* a, Asiento* b) {
                return a->getPrecio() < b->getPrecio();
            };
            extractorValor = [](Asiento* a) {
                return a->getPrecio();
            };
            extractorEntero = [](Asiento* a) {
                return static_cast<int>(a->getPrecio());
            };
            break;
        case 3: // Por Tipo
            comparador = [](Asiento* a, Asiento* b) {
                if (a->getTipo() == b->getTipo()) return a->getId() < b->getId();
                return a->getTipo() > b->getTipo(); // VIP > General
            };
            extractorValor = [](Asiento* a) {
                return (a->getTipo() == "VIP") ? 1.0 : 0.0;
            };
            extractorEntero = [](Asiento* a) {
                return (a->getTipo() == "VIP") ? 1 : 0;
            };
            break;
        case 4: // Por Estado
            comparador = [](Asiento* a, Asiento* b) {
                if (a->isOcupado() == b->isOcupado()) return a->getId() < b->getId();
                return !a->isOcupado(); // Disponibles primero
            };
            extractorValor = [](Asiento* a) {
                return a->isOcupado() ? 1.0 : 0.0;
            };
            extractorEntero = [](Asiento* a) {
                return a->isOcupado() ? 1 : 0;
            };
            break;
    }
    
    // Ejecutar algoritmo
    vista->mostrarMensaje("\n[INFO] Ordenando asientos...");
    auto inicioTiempo = std::chrono::high_resolution_clock::now();
    
    switch (algoritmo) {
        case 1:
            AlgoritmosOrdenamiento<Asiento*>::bubbleSort(salaSeleccionada->getAsientos(), comparador);
            vista->mostrarMensaje("[EXITO] Asientos ordenados con Bubble Sort");
            break;
        case 2:
            AlgoritmosOrdenamiento<Asiento*>::selectionSort(salaSeleccionada->getAsientos(), comparador);
            vista->mostrarMensaje("[EXITO] Asientos ordenados con Selection Sort");
            break;
        case 3:
            AlgoritmosOrdenamiento<Asiento*>::insertionSort(salaSeleccionada->getAsientos(), comparador);
            vista->mostrarMensaje("[EXITO] Asientos ordenados con Insertion Sort");
            break;
        case 4:
            AlgoritmosOrdenamiento<Asiento*>::mergeSort(salaSeleccionada->getAsientos(), comparador);
            vista->mostrarMensaje("[EXITO] Asientos ordenados con Merge Sort");
            break;
        case 5:
            AlgoritmosOrdenamiento<Asiento*>::quickSort(salaSeleccionada->getAsientos(), comparador);
            vista->mostrarMensaje("[EXITO] Asientos ordenados con Quick Sort");
            break;
        case 6:
            AlgoritmosOrdenamiento<Asiento*>::bucketSort(salaSeleccionada->getAsientos(), extractorValor, comparador);
            vista->mostrarMensaje("[EXITO] Asientos ordenados con Bucket Sort");
            break;
        case 7:
            AlgoritmosOrdenamiento<Asiento*>::radixSort(salaSeleccionada->getAsientos(), extractorEntero);
            vista->mostrarMensaje("[EXITO] Asientos ordenados con Radix Sort");
            break;
        case 8:
            AlgoritmosOrdenamiento<Asiento*>::countingSort(salaSeleccionada->getAsientos(), extractorEntero, 50);
            vista->mostrarMensaje("[EXITO] Asientos ordenados con Counting Sort");
            break;
    }
    
    auto finTiempo = std::chrono::high_resolution_clock::now();
    auto duracion = std::chrono::duration_cast<std::chrono::microseconds>(finTiempo - inicioTiempo);
    
    std::cout << "Tiempo de ejecucion: " << duracion.count() << " microsegundos" << std::endl;
    
    // Mostrar asientos ordenados
    vista->mostrarMensaje("\n--- ASIENTOS ORDENADOS ---");
    salaSeleccionada->mostrarAsientos();
}
