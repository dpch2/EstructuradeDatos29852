#ifndef VISTA_H
#define VISTA_H

#include <iostream>
#include <string>

class Vista {
public:
    // Menús principales
    void mostrarMenu();
    void mostrarMenuAsientos();
    
    // Nuevos menús de ordenamiento
    void mostrarMenuOrdenamiento();
    void mostrarMenuAlgoritmos();
    void mostrarMenuCriteriosUsuarios();
    void mostrarMenuCriteriosReservas();
    void mostrarMenuCriteriosAsientos();
    
    // Métodos de interacción
    void mostrarMensaje(std::string mensaje);
    int leerInt(std::string prompt);
    int leerIntEnRango(std::string prompt, int min, int max);
    std::string leerString(std::string prompt);
};

#endif