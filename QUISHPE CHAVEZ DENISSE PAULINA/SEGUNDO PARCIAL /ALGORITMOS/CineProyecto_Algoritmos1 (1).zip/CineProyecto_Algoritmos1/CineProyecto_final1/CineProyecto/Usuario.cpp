#include "Usuario.h"
#include "include/json.hpp"
#include <algorithm>
#include <cctype>

Usuario::Usuario(std::string n, int e, std::string g, std::string c, std::string d, std::string t)
    : nombre(n), edad(e), genero(g), cedula(c), direccion(d), telefono(t) {}

bool Usuario::validarNombre() {
    if (nombre.empty()) return false;
    
    // Verificar que solo contenga letras y espacios
    for (char c : nombre) {
        if (!isalpha(c) && c != ' ') {
            return false;
        }
    }
    return true;
}

bool Usuario::validarCedula() {
    if (cedula.length() != 10) return false;
    int suma = 0;
    for (int i = 0; i < 9; i++) {
        int digito = cedula[i] - '0';
        if (i % 2 == 0) {
            digito *= 2;
            if (digito > 9) digito -= 9;
        }
        suma += digito;
    }
    int verificador = (10 - (suma % 10)) % 10;
    return verificador == (cedula[9] - '0');
}

bool Usuario::validarEdad() {
    return edad >= 18;
}

bool Usuario::validarGenero() {
    return genero == "Hombre" || genero == "Mujer";
}

bool Usuario::validarTelefono() {
    return telefono.length() == 10 && std::all_of(telefono.begin(), telefono.end(), ::isdigit);
}

bool Usuario::esValido() {
    return validarNombre() && validarCedula() && validarEdad() && validarGenero() && validarTelefono();
}

toon::TOON Usuario::toToon() const {
    toon::TOON t = toon::TOON::object();
    t["nombre"] = toon::TOON(nombre);
    t["edad"] = toon::TOON(edad);
    t["genero"] = toon::TOON(genero);
    t["cedula"] = toon::TOON(cedula);
    t["direccion"] = toon::TOON(direccion);
    t["telefono"] = toon::TOON(telefono);
    return t;
}

Usuario* Usuario::fromToon(const toon::TOON& t) {
    const toon::TOON* nombre_t = t.get("nombre");
    const toon::TOON* edad_t = t.get("edad");
    const toon::TOON* genero_t = t.get("genero");
    const toon::TOON* cedula_t = t.get("cedula");
    const toon::TOON* direccion_t = t.get("direccion");
    const toon::TOON* telefono_t = t.get("telefono");
    
    std::string nombre = nombre_t ? nombre_t->string_value : "";
    int edad = edad_t ? static_cast<int>(edad_t->number_value) : 0;
    std::string genero = genero_t ? genero_t->string_value : "";
    std::string cedula = cedula_t ? cedula_t->string_value : "";
    std::string direccion = direccion_t ? direccion_t->string_value : "";
    std::string telefono = telefono_t ? telefono_t->string_value : "";
    
    return new Usuario(nombre, edad, genero, cedula, direccion, telefono);
}