#include "Vista.h"
#include <limits>
#include <algorithm>

void Vista::mostrarMenu() {
    std::cout << "\n================================" << std::endl;
    std::cout << "  SISTEMA DE RESERVAS DE CINE  " << std::endl;
    std::cout << "================================" << std::endl;
    std::cout << "1. Registrar Reserva" << std::endl;
    std::cout << "2. Ver Reporte General" << std::endl;
    std::cout << "3. Cancelar Reserva" << std::endl;
    std::cout << "4. Ordenar Reservas" << std::endl;
    std::cout << "5. Salir" << std::endl;
    std::cout << "================================" << std::endl;
}

void Vista::mostrarMenuAsientos() {
    std::cout << "\n=== MENU DE GESTION DE ASIENTOS ===" << std::endl;
    std::cout << "1. Insertar asientos" << std::endl;
    std::cout << "2. Eliminar asientos" << std::endl;
    std::cout << "3. Buscar asiento" << std::endl;
    std::cout << "4. Ver asientos seleccionados" << std::endl;
    std::cout << "5. Confirmar y continuar" << std::endl;
    std::cout << "6. Cancelar reserva" << std::endl;
    std::cout << "7. Regresar" << std::endl;
    std::cout << "====================================" << std::endl;
}

void Vista::mostrarMenuOrdenamiento() {
    std::cout << "\n========================================" << std::endl;
    std::cout << "      MENU DE ORDENAMIENTO DE DATOS     " << std::endl;
    std::cout << "========================================" << std::endl;
    std::cout << "Seleccione el tipo de datos a ordenar:" << std::endl;
    std::cout << "\n1. Ordenar Usuarios" << std::endl;
    std::cout << "2. Ordenar Reservas" << std::endl;
    std::cout << "3. Ordenar Asientos de una Sala" << std::endl;
    std::cout << "0. Regresar al Menu Principal" << std::endl;
    std::cout << "========================================" << std::endl;
}

void Vista::mostrarMenuAlgoritmos() {
    std::cout << "\n========================================" << std::endl;
    std::cout << "     SELECCIONE ALGORITMO DE ORDENAMIENTO" << std::endl;
    std::cout << "========================================" << std::endl;
    std::cout << "\nAlgoritmos de complejidad O(n^2):" << std::endl;
    std::cout << "  1. Bubble Sort" << std::endl;
    std::cout << "  2. Selection Sort" << std::endl;
    std::cout << "  3. Insertion Sort" << std::endl;
    std::cout << "\nAlgoritmos de complejidad O(n log n):" << std::endl;
    std::cout << "  4. Merge Sort" << std::endl;
    std::cout << "  5. Quick Sort" << std::endl;
    std::cout << "\nAlgoritmos especializados:" << std::endl;
    std::cout << "  6. Bucket Sort" << std::endl;
    std::cout << "  7. Radix Sort" << std::endl;
    std::cout << "  8. Counting Sort" << std::endl;
    std::cout << "\n  0. Regresar" << std::endl;
    std::cout << "========================================" << std::endl;
}

void Vista::mostrarMenuCriteriosUsuarios() {
    std::cout << "\n========================================" << std::endl;
    std::cout << "      CRITERIOS DE ORDENAMIENTO         " << std::endl;
    std::cout << "            USUARIOS                    " << std::endl;
    std::cout << "========================================" << std::endl;
    std::cout << "1. Por Nombre (A-Z)" << std::endl;
    std::cout << "2. Por Cedula (menor a mayor)" << std::endl;
    std::cout << "3. Por Edad (menor a mayor)" << std::endl;
    std::cout << "0. Regresar" << std::endl;
    std::cout << "========================================" << std::endl;
}

void Vista::mostrarMenuCriteriosReservas() {
    std::cout << "\n========================================" << std::endl;
    std::cout << "      CRITERIOS DE ORDENAMIENTO         " << std::endl;
    std::cout << "            RESERVAS                    " << std::endl;
    std::cout << "========================================" << std::endl;
    std::cout << "1. Por Fecha (mas reciente primero)" << std::endl;
    std::cout << "2. Por Total (menor a mayor)" << std::endl;
    std::cout << "3. Por Nombre del Cliente (A-Z)" << std::endl;
    std::cout << "4. Por Numero de Asientos (menor a mayor)" << std::endl;
    std::cout << "0. Regresar" << std::endl;
    std::cout << "========================================" << std::endl;
}

void Vista::mostrarMenuCriteriosAsientos() {
    std::cout << "\n========================================" << std::endl;
    std::cout << "      CRITERIOS DE ORDENAMIENTO         " << std::endl;
    std::cout << "            ASIENTOS                    " << std::endl;
    std::cout << "========================================" << std::endl;
    std::cout << "1. Por ID (A1, A2, ... B1, B2, ...)" << std::endl;
    std::cout << "2. Por Precio (menor a mayor)" << std::endl;
    std::cout << "3. Por Tipo (VIP primero)" << std::endl;
    std::cout << "4. Por Estado (Disponibles primero)" << std::endl;
    std::cout << "0. Regresar" << std::endl;
    std::cout << "========================================" << std::endl;
}

void Vista::mostrarMensaje(std::string mensaje) {
    std::cout << mensaje << std::endl;
}

int Vista::leerInt(std::string prompt) {
    int valor;
    while (true) {
        std::cout << prompt;
        if (std::cin >> valor) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return valor;
        } else {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "[ERROR] Entrada invalida. Ingrese un numero entero." << std::endl;
        }
    }
}

int Vista::leerIntEnRango(std::string prompt, int min, int max) {
    int valor;
    while (true) {
        valor = leerInt(prompt);
        if (valor >= min && valor <= max) {
            return valor;
        } else {
            std::cout << "[ERROR] Debe ingresar un numero entre " << min << " y " << max << "." << std::endl;
        }
    }
}

std::string Vista::leerString(std::string prompt) {
    std::string valor;
    std::cout << prompt;
    std::getline(std::cin, valor);
    if (valor.empty()) {
        // Intentar leer otra vez si quedó newline pendiente
    }
    return valor;
}