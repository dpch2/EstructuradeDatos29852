#include "Vista.h"
#include <limits>
#include <algorithm>

void Vista::mostrarMenu() {
    std::cout << "\n================================" << std::endl;
    std::cout << "  SISTEMA DE RESERVAS DE CINE  " << std::endl;
    std::cout << "================================" << std::endl;
    std::cout << "1. Registrar Reserva" << std::endl;
    std::cout << "2. Ver Reporte General" << std::endl;
    std::cout << "3. Cancelar Reserva" << std::endl;
    std::cout << "4. Salir" << std::endl;
    std::cout << "================================" << std::endl;
}

void Vista::mostrarMenuAsientos() {
    std::cout << "\n=== MENU DE GESTION DE ASIENTOS ===" << std::endl;
    std::cout << "1. Insertar asientos" << std::endl;
    std::cout << "2. Eliminar asientos" << std::endl;
    std::cout << "3. Buscar asiento" << std::endl;
    std::cout << "4. Ver asientos seleccionados" << std::endl;
    std::cout << "5. Confirmar y continuar" << std::endl;
    std::cout << "6. Cancelar reserva" << std::endl;
    std::cout << "7. Regresar" << std::endl;
    std::cout << "====================================" << std::endl;
}

void Vista::mostrarMensaje(std::string mensaje) {
    std::cout << mensaje << std::endl;
}

int Vista::leerInt(std::string prompt) {
    int valor;
    while (true) {
        std::cout << prompt;
        if (std::cin >> valor) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return valor;
        } else {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "[ERROR] Entrada invalida. Ingrese un numero entero." << std::endl;
        }
    }
}

int Vista::leerIntEnRango(std::string prompt, int min, int max) {
    int valor;
    while (true) {
        valor = leerInt(prompt);
        if (valor >= min && valor <= max) {
            return valor;
        } else {
            std::cout << "[ERROR] Debe ingresar un numero entre " << min << " y " << max << "." << std::endl;
        }
    }
}

std::string Vista::leerString(std::string prompt) {
    std::string valor;
    // Garantiza que no quede newline pendiente
    std::cout << prompt;
    std::getline(std::cin, valor);
    // si getline devuelve string vacío por leftover, volver a intentar
    if (valor.empty()) {
        // intentar leer otra vez (acepta cadena vacía como entrada intencional)
        // no forzamos reintento aquí porque a veces el usuario desea cadena vacía
    }
    return valor;
}