#ifndef CONTROLADOR_H
#define CONTROLADOR_H

#include "Modelo.h"
#include "Vista.h"
#include "Reserva.h"
#include "Usuario.h"
#include "Funcion.h"
#include "Sala.h"
#include <string>

class Controlador {
private:
    Modelo* modelo;
    Vista* vista;
    
    void registrarReserva();
    void verReporte();
    void cancelarReserva();
    void seleccionarFechas();
    void mostrarPeliculasPorFecha(const std::string& fecha);
    
    Usuario* obtenerORegistrarUsuario();
    
    bool gestionarAsientos(ListaDobleCircular<Asiento*>& asientosSeleccionados, 
                          Sala* sala, double& total);
    void insertarMultiplesAsientos(ListaDobleCircular<Asiento*>& asientosSeleccionados, 
                                   Sala* sala, double& total);
    void eliminarMultiplesAsientos(ListaDobleCircular<Asiento*>& asientosSeleccionados, double& total);
    void buscarAsiento(ListaDobleCircular<Asiento*>& asientosSeleccionados);
    void imprimirAsientosSeleccionados(ListaDobleCircular<Asiento*>& asientosSeleccionados);
    void imprimirResumenAsientos(ListaDobleCircular<Asiento*>& asientosSeleccionados, double total);
    void liberarAsientosTemporales(ListaDobleCircular<Asiento*>& asientosSeleccionados);
    
    std::string obtenerFechaActual();
    std::string obtenerHoraActual();
    std::string obtenerFechaFormato(int diasDesdeHoy);
    std::string convertirAMinusculas(const std::string& texto);
    
public:
    Controlador(Modelo* m, Vista* v) : modelo(m), vista(v) {}
    void ejecutar();
};

#endif