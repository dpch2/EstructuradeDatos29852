#ifndef NODO_H
#define NODO_H

template <typename T>
class Nodo {
public:
    T data;
    Nodo* prev;
    Nodo* next;
    Nodo(T d) : data(d), prev(nullptr), next(nullptr) {}
};

#endif