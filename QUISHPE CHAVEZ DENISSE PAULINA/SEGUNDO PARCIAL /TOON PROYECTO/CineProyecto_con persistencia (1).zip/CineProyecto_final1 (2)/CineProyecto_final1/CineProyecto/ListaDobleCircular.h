#ifndef LISTADOBLECIRCULAR_H
#define LISTADOBLECIRCULAR_H

#include "Nodo.h"
#include <iostream>

template <typename T>
class ListaDobleCircular {
private:
    Nodo<T>* head;
    int size;
public:
    ListaDobleCircular() : head(nullptr), size(0) {}
    
    ~ListaDobleCircular() {
        while (size > 0) {
            eliminarCabeza();
        }
    }
    
    void insertarCabeza(T data) {
        Nodo<T>* nuevo = new Nodo<T>(data);
        if (head == nullptr) {
            head = nuevo;
            head->next = head;
            head->prev = head;
        } else {
            nuevo->next = head;
            nuevo->prev = head->prev;
            head->prev->next = nuevo;
            head->prev = nuevo;
            head = nuevo;
        }
        size++;
    }
    
    void insertarCola(T data) {
        Nodo<T>* nuevo = new Nodo<T>(data);
        if (head == nullptr) {
            head = nuevo;
            head->next = head;
            head->prev = head;
        } else {
            nuevo->next = head;
            nuevo->prev = head->prev;
            head->prev->next = nuevo;
            head->prev = nuevo;
        }
        size++;
    }
    
    void eliminarCabeza() {
        if (head == nullptr) return;
        if (size == 1) {
            delete head;
            head = nullptr;
        } else {
            Nodo<T>* temp = head;
            head->prev->next = head->next;
            head->next->prev = head->prev;
            head = head->next;
            delete temp;
        }
        size--;
    }
    
    void eliminarCola() {
        if (head == nullptr) return;
        if (size == 1) {
            delete head;
            head = nullptr;
        } else {
            Nodo<T>* temp = head->prev;
            temp->prev->next = head;
            head->prev = temp->prev;
            delete temp;
        }
        size--;
    }
    
    void imprimir() {
        if (head == nullptr) {
            std::cout << "Lista vacia" << std::endl;
            return;
        }
        Nodo<T>* current = head;
        do {
            std::cout << current->data << " ";
            current = current->next;
        } while (current != head);
        std::cout << std::endl;
    }
    
    Nodo<T>* buscar(T data) {
        if (head == nullptr) return nullptr;
        Nodo<T>* current = head;
        do {
            if (current->data == data) return current;
            current = current->next;
        } while (current != head);
        return nullptr;
    }
    
    Nodo<T>* getHead() { return head; }
    int getSize() { return size; }
    void eliminarNodo(Nodo<T>* nodo) {
        if (nodo == nullptr) return;
        if (head == nullptr) return;
        if (nodo == head) {
            eliminarCabeza();
            return;
        }
        if (nodo == head->prev) {
            eliminarCola();
            return;
        }
        nodo->prev->next = nodo->next;
        nodo->next->prev = nodo->prev;
        delete nodo;
        size--;
    }
};

#endif