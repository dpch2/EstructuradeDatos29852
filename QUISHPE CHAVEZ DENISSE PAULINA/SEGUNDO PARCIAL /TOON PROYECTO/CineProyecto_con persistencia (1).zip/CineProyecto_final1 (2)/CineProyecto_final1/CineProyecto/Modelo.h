#ifndef MODELO_H
#define MODELO_H

#include "Pelicula.h"
#include "Funcion.h"
#include "Sala.h"
#include "Reserva.h"
#include "ListaDobleCircular.h"
#include "Usuario.h"
#include "include/toon.hpp"
#include <fstream>

class Modelo {
private:
    ListaDobleCircular<Pelicula*> peliculas;
    ListaDobleCircular<Funcion*> funciones;
    ListaDobleCircular<Sala*> salas;
    ListaDobleCircular<Reserva*> reservas;
    ListaDobleCircular<Usuario*> usuarios;
public:
    Modelo();
    ListaDobleCircular<Pelicula*>& getPeliculas() { return peliculas; }
    ListaDobleCircular<Funcion*>& getFunciones() { return funciones; }
    ListaDobleCircular<Sala*>& getSalas() { return salas; }
    ListaDobleCircular<Reserva*>& getReservas() { return reservas; }
    ListaDobleCircular<Usuario*>& getUsuarios() { return usuarios; }
    
    void agregarReserva(Reserva* r);
    void eliminarReserva(Reserva* r);
    void agregarUsuario(Usuario* u);
    Usuario* buscarUsuarioPorCedula(std::string cedula);
    void actualizarAsientosEnSala(Sala* sala, std::string fecha);
    
    void guardarReservas();
    void cargarReservas();
    void guardarUsuarios();
    void cargarUsuarios();
    ~Modelo();
};

#endif