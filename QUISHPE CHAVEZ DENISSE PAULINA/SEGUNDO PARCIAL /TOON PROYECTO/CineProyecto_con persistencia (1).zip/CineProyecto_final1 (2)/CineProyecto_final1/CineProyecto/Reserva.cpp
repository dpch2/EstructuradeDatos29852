#include "Reserva.h"
#include "Modelo.h"
#include "ListaDobleCircular.h"

Reserva::Reserva(Usuario* u, Funcion* f, ListaDobleCircular<Asiento*>& a, double t, std::string fechaRes)
    : usuario(u), funcion(f), total(t), fecha(fechaRes) {
    asientosSeleccionados = new ListaDobleCircular<Asiento*>();
    Nodo<Asiento*>* cur = a.getHead();
    if (cur != nullptr) {
        do {
            asientosSeleccionados->insertarCola(cur->data);
            cur = cur->next;
        } while (cur != a.getHead());
    }
}

Reserva::~Reserva() {
    if (asientosSeleccionados) {
        delete asientosSeleccionados;
        asientosSeleccionados = nullptr;
    }
}

toon::TOON Reserva::toToon() const {
    toon::TOON t = toon::TOON::object();
    t["usuario"] = usuario->toToon();
    t["funcionId"] = toon::TOON(funcion->getSalaId());
    t["horario"] = toon::TOON(funcion->getHorario());
    t["fecha"] = toon::TOON(fecha);
    t["total"] = toon::TOON(total);
    
    toon::TOON asientos = toon::TOON::array();
    Nodo<Asiento*>* cur = asientosSeleccionados->getHead();
    if (cur != nullptr) {
        do {
            asientos.push_back(toon::TOON(cur->data->getId()));
            cur = cur->next;
        } while (cur != asientosSeleccionados->getHead());
    }
    t["asientos"] = asientos;
    
    return t;
}

Reserva* Reserva::fromToon(const toon::TOON& t, Modelo* modelo) {
    // obtener usuario
    const toon::TOON* u_t = t.get("usuario");
    Usuario* usuario = nullptr;
    if (u_t) {
        const toon::TOON* ced_t = u_t->get("cedula");
        std::string cedula = ced_t ? ced_t->string_value : "";
        if (!cedula.empty()) {
            usuario = modelo->buscarUsuarioPorCedula(cedula);
        }
        if (!usuario) {
            usuario = Usuario::fromToon(*u_t);
            if (usuario) modelo->agregarUsuario(usuario);
        }
    }

    // obtener funcion (buscamos por salaId y horario)
    int salaId = 0;
    const toon::TOON* fId = t.get("funcionId");
    if (fId) salaId = static_cast<int>(fId->number_value);
    const toon::TOON* horario_t = t.get("horario");
    std::string horario = horario_t ? horario_t->string_value : "";

    Funcion* funcion = nullptr;
    Nodo<Funcion*>* cf = modelo->getFunciones().getHead();
    if (cf) {
        Nodo<Funcion*>* inicioF = cf;
        do {
            if (cf->data->getSalaId() == salaId && cf->data->getHorario() == horario) {
                funcion = cf->data; break;
            }
            cf = cf->next;
        } while (cf != inicioF);
    }

    std::string fecha = "";
    const toon::TOON* fecha_t = t.get("fecha");
    if (fecha_t) fecha = fecha_t->string_value;

    double total = 0.0;
    const toon::TOON* total_t = t.get("total");
    if (total_t) total = total_t->number_value;

    // recolectar asientos
    ListaDobleCircular<Asiento*> listaAsientos;
    const toon::TOON* asientos_t = t.get("asientos");
    if (asientos_t && asientos_t->type == toon::TOON::ARRAY) {
        toon::TOONNode* nodo = asientos_t->array_head;
        // buscar sala para localizar asientos
        Sala* sala = nullptr;
        Nodo<Sala*>* cs = modelo->getSalas().getHead();
        if (cs) {
            Nodo<Sala*>* inicioS = cs;
            do {
                if (cs->data->getId() == salaId) { sala = cs->data; break; }
                cs = cs->next;
            } while (cs != inicioS);
        }

        while (nodo != nullptr) {
            if (nodo->value && nodo->value->type == toon::TOON::STRING) {
                std::string aid = nodo->value->string_value;
                if (sala) {
                    Asiento* a = sala->buscarAsientoPorId(aid);
                    if (a) listaAsientos.insertarCola(a);
                }
            }
            nodo = nodo->next;
        }
    }

    if (!usuario || !funcion) return nullptr;

    Reserva* r = new Reserva(usuario, funcion, listaAsientos, total, fecha);
    return r;
}
