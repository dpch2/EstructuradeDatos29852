#ifndef USUARIO_H
#define USUARIO_H

#include <string>
#include "include/toon.hpp"

class Usuario {
private:
    std::string nombre;
    int edad;
    std::string genero;
    std::string cedula;
    std::string direccion;
    std::string telefono;
public:
    Usuario(std::string n, int e, std::string g, std::string c, std::string d, std::string t);
    std::string getNombre() { return nombre; }
    int getEdad() { return edad; }
    std::string getGenero() { return genero; }
    std::string getCedula() { return cedula; }
    std::string getDireccion() { return direccion; }
    std::string getTelefono() { return telefono; }
    bool validarNombre();
    bool validarCedula();
    bool validarEdad();
    bool validarGenero();
    bool validarTelefono();
    bool esValido();
    toon::TOON toToon() const;
    static Usuario* fromToon(const toon::TOON& t);
};

#endif