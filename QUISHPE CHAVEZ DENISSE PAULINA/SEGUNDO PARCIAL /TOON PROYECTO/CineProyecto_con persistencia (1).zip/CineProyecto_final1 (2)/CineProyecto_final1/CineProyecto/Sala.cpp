#include "Sala.h"
#include <iostream>

Sala::Sala(int i) : id(i) {
    double precioVIP = 15.0;
    double precioGeneral = 10.0;
    
    // Filas VIP: A y B (2 filas)
    char filaLetra = 'A';
    for (int f = 1; f <= 2; f++) {
        for (int c = 1; c <= 6; c++) {
            std::string idAsiento = std::string(1, filaLetra) + std::to_string(c);
            Asiento* asiento = new Asiento(idAsiento, f, c, "VIP", precioVIP);
            asientos.insertarCola(asiento);
        }
        filaLetra++;
    }
    
    // Filas General: C, D, E (3 filas)
    for (int f = 3; f <= 5; f++) {
        for (int c = 1; c <= 6; c++) {
            std::string idAsiento = std::string(1, filaLetra) + std::to_string(c);
            Asiento* asiento = new Asiento(idAsiento, f, c, "General", precioGeneral);
            asientos.insertarCola(asiento);
        }
        filaLetra++;
    }
}

void Sala::mostrarAsientos() {
    std::cout << "\n=== Sala " << id << " ===" << std::endl;
    std::cout << "        PANTALLA" << std::endl;
    std::cout << "========================" << std::endl;
    
    Nodo<Asiento*>* current = asientos.getHead();
    if (current == nullptr) return;
    
    int filaActual = 1;
    std::cout << "\nAsientos VIP ($15.00):" << std::endl;
    
    do {
        if (current->data->getFila() != filaActual) {
            std::cout << std::endl;
            filaActual = current->data->getFila();
            if (filaActual == 3) {
                std::cout << "\nAsientos General ($10.00):" << std::endl;
            }
        }
        
        if (current->data->isOcupado()) {
            std::cout << " 0  ";
        } else {
            std::cout << current->data->getId();
            if (current->data->getId().length() == 2) {
                std::cout << "  ";
            } else {
                std::cout << " ";
            }
        }
        
        current = current->next;
    } while (current != asientos.getHead());
    
    std::cout << std::endl << std::endl;
}

Asiento* Sala::buscarAsientoPorId(std::string id) {
    Nodo<Asiento*>* current = asientos.getHead();
    if (current == nullptr) return nullptr;
    
    do {
        if (current->data->getId() == id) {
            return current->data;
        }
        current = current->next;
    } while (current != asientos.getHead());
    
    return nullptr;
}

int Sala::contarAsientosDisponibles() {
    int count = 0;
    Nodo<Asiento*>* current = asientos.getHead();
    if (current == nullptr) return 0;
    
    do {
        if (!current->data->isOcupado()) {
            count++;
        }
        current = current->next;
    } while (current != asientos.getHead());
    
    return count;
}

int Sala::contarAsientosOcupados() {
    return asientos.getSize() - contarAsientosDisponibles();
}