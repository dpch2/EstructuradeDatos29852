#include "Modelo.h"
#include <iostream>

int main() {
    Modelo modelo;
    std::cout << "\n== Test: Carga de reservas desde reservas.txt ==\n";
    std::cout << "Reservas cargadas en memoria: " << modelo.getReservas().getSize() << std::endl;

    Nodo<Reserva*>* cur = modelo.getReservas().getHead();
    if (cur) {
        int idx = 1;
        Nodo<Reserva*>* inicio = cur;
        do {
            Reserva* r = cur->data;
            std::cout << idx << ". Cliente=" << r->getUsuario()->getNombre()
                      << " Cedula=" << r->getUsuario()->getCedula()
                      << " Fecha=" << r->getFecha()
                      << " Sala=" << r->getFuncion()->getSalaId()
                      << " Horario=" << r->getFuncion()->getHorario()
                      << " Asientos=" << r->getAsientos().getSize()
                      << " Total=$" << r->getTotal() << std::endl;
            cur = cur->next; idx++;
        } while (cur != inicio);
    }

    return 0;
}
