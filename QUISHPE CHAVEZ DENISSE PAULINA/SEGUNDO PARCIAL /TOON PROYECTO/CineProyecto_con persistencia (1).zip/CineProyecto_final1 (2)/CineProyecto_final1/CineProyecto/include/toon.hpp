#ifndef TOON_HPP
#define TOON_HPP

#include <string>
#include <sstream>
#include <cstring>

namespace toon {

// Nodo para lista enlazada de TOON
class TOONNode {
public:
    std::string key;
    class TOON* value;
    TOONNode* next;
    TOONNode* prev;
    
    TOONNode(const std::string& k = "", TOON* v = nullptr)
        : key(k), value(v), next(nullptr), prev(nullptr) {}
};

class TOON {
public:
    enum Type { NIL, BOOL, NUMBER, STRING, ARRAY, OBJECT };
    
    Type type;
    bool bool_value;
    double number_value;
    std::string string_value;
    TOONNode* array_head;  // Para arrays
    TOONNode* object_head; // Para objetos
    int array_size;
    int object_size;
    
    TOON() : type(NIL), bool_value(false), number_value(0), 
             array_head(nullptr), object_head(nullptr), array_size(0), object_size(0) {}
    
    TOON(bool b) : type(BOOL), bool_value(b), number_value(0),
                   array_head(nullptr), object_head(nullptr), array_size(0), object_size(0) {}
    
    TOON(int n) : type(NUMBER), bool_value(false), number_value(n),
                  array_head(nullptr), object_head(nullptr), array_size(0), object_size(0) {}
    
    TOON(double n) : type(NUMBER), bool_value(false), number_value(n),
                     array_head(nullptr), object_head(nullptr), array_size(0), object_size(0) {}
    
    TOON(const std::string& s) : type(STRING), bool_value(false), number_value(0), 
                                  string_value(s), array_head(nullptr), object_head(nullptr), 
                                  array_size(0), object_size(0) {}
    
    TOON(const char* s) : type(STRING), bool_value(false), number_value(0), 
                          string_value(s), array_head(nullptr), object_head(nullptr),
                          array_size(0), object_size(0) {}
    
    ~TOON() {
        clear();
    }
    
    void clear() {
        // Limpiar array
        TOONNode* current = array_head;
        while (current != nullptr) {
            TOONNode* next = current->next;
            if (current->value) delete current->value;
            delete current;
            current = next;
        }
        array_head = nullptr;
        
        // Limpiar objeto
        current = object_head;
        while (current != nullptr) {
            TOONNode* next = current->next;
            if (current->value) delete current->value;
            delete current;
            current = next;
        }
        object_head = nullptr;
        
        array_size = 0;
        object_size = 0;
    }
    
    TOON(const TOON& other) : type(NIL), bool_value(false), number_value(0),
                              array_head(nullptr), object_head(nullptr), 
                              array_size(0), object_size(0) {
        *this = other;
    }
    
    TOON& operator=(const TOON& other) {
        if (this == &other) return *this;
        
        clear();
        type = other.type;
        bool_value = other.bool_value;
        number_value = other.number_value;
        string_value = other.string_value;
        array_size = 0;
        object_size = 0;
        
        // Copiar array
        TOONNode* current = other.array_head;
        while (current != nullptr) {
            if (current->value) {
                push_back(*current->value);
            }
            current = current->next;
        }
        
        // Copiar objeto
        current = other.object_head;
        while (current != nullptr) {
            if (current->value) {
                (*this)[current->key] = *current->value;
            }
            current = current->next;
        }
        
        return *this;
    }
    
    static TOON array() {
        TOON t;
        t.type = ARRAY;
        return t;
    }
    
    static TOON object() {
        TOON t;
        t.type = OBJECT;
        return t;
    }
    
    void push_back(const TOON& v) {
        if (type != ARRAY) type = ARRAY;
        
        TOON* new_val = new TOON(v);
        TOONNode* new_node = new TOONNode("", new_val);
        
        if (array_head == nullptr) {
            array_head = new_node;
        } else {
            TOONNode* current = array_head;
            while (current->next != nullptr) {
                current = current->next;
            }
            current->next = new_node;
            new_node->prev = current;
        }
        array_size++;
    }
    
    TOON& operator[](const std::string& key) {
        if (type != OBJECT) type = OBJECT;
        
        // Buscar clave existente
        TOONNode* current = object_head;
        while (current != nullptr) {
            if (current->key == key) {
                return *current->value;
            }
            current = current->next;
        }
        
        // Crear nueva clave
        TOON* new_val = new TOON();
        TOONNode* new_node = new TOONNode(key, new_val);
        
        if (object_head == nullptr) {
            object_head = new_node;
        } else {
            current = object_head;
            while (current->next != nullptr) {
                current = current->next;
            }
            current->next = new_node;
            new_node->prev = current;
        }
        object_size++;
        
        return *new_val;
    }
    
    TOON& operator[](size_t index) {
        if (type != ARRAY) type = ARRAY;
        
        TOONNode* current = array_head;
        size_t i = 0;
        while (current != nullptr && i < index) {
            current = current->next;
            i++;
        }
        
        if (current == nullptr) {
            // Crear nodos hasta llegar al indice
            while (i < index) {
                push_back(TOON());
                i++;
            }
            push_back(TOON());
            current = array_head;
            i = 0;
            while (i < index) {
                current = current->next;
                i++;
            }
        }
        
        return *current->value;
    }
    
    size_t size() const {
        if (type == ARRAY) return array_size;
        if (type == OBJECT) return object_size;
        return 0;
    }
    
    // Metodos getter para acceso seguro
    const TOON* get(const std::string& key) const {
        TOONNode* current = object_head;
        while (current != nullptr) {
            if (current->key == key) {
                return current->value;
            }
            current = current->next;
        }
        return nullptr;
    }
    
    std::string dump(int indent = -1) const {
        std::stringstream ss;
        dump_internal(ss, indent, 0);
        return ss.str();
    }
    
private:
    void dump_internal(std::stringstream& ss, int indent_level, int depth) const {
        std::string indent_str = "";
        std::string next_indent_str = "";
        
        if (indent_level >= 0) {
            for (int i = 0; i < depth * indent_level; i++) indent_str += " ";
            for (int i = 0; i < (depth + 1) * indent_level; i++) next_indent_str += " ";
        }
        
        switch (type) {
            case NIL:
                ss << "null";
                break;
            case BOOL:
                ss << (bool_value ? "true" : "false");
                break;
            case NUMBER:
                ss << number_value;
                break;
            case STRING:
                ss << "\"" << string_value << "\"";
                break;
            case ARRAY: {
                ss << "[";
                if (indent_level >= 0 && array_size > 0) ss << "\n";
                TOONNode* current = array_head;
                int count = 0;
                while (current != nullptr) {
                    if (indent_level >= 0) ss << next_indent_str;
                    if (current->value) {
                        current->value->dump_internal(ss, indent_level, depth + 1);
                    }
                    count++;
                    if (count < array_size) ss << ",";
                    if (indent_level >= 0) ss << "\n";
                    current = current->next;
                }
                if (indent_level >= 0 && array_size > 0) ss << indent_str;
                ss << "]";
                break;
            }
            case OBJECT: {
                ss << "{";
                if (indent_level >= 0 && object_size > 0) ss << "\n";
                TOONNode* current = object_head;
                int count = 0;
                while (current != nullptr) {
                    if (indent_level >= 0) ss << next_indent_str;
                    ss << "\"" << current->key << "\":";
                    if (indent_level >= 0) ss << " ";
                    if (current->value) {
                        current->value->dump_internal(ss, indent_level, depth + 1);
                    }
                    count++;
                    if (count < object_size) ss << ",";
                    if (indent_level >= 0) ss << "\n";
                    current = current->next;
                }
                if (indent_level >= 0 && object_size > 0) ss << indent_str;
                ss << "}";
                break;
            }
        }
    }
};

}

#endif
