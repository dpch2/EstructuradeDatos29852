#ifndef ASIENTO_H
#define ASIENTO_H

#include <string>

class Asiento {
private:
    std::string id; // Ejemplo: "A1", "B3", "C5"
    int fila;
    int columna;
    std::string tipo;
    bool ocupado;
    bool reservadoTemporal; // Para bloqueo durante selección
    double precio;
public:
    Asiento(std::string i, int f, int c, std::string t, double p) 
        : id(i), fila(f), columna(c), tipo(t), ocupado(false), reservadoTemporal(false), precio(p) {}
    std::string getId() { return id; }
    int getFila() { return fila; }
    int getColumna() { return columna; }
    std::string getTipo() { return tipo; }
    bool isOcupado() { return ocupado; }
    bool isReservadoTemporal() { return reservadoTemporal; }
    void ocupar() { ocupado = true; }
    void liberar() { ocupado = false; }
    void reservarTemporal() { reservadoTemporal = true; }
    void liberarTemporal() { reservadoTemporal = false; }
    double getPrecio() { return precio; }
};

#endif