#ifndef RESERVA_H
#define RESERVA_H

#include "Usuario.h"
#include "Funcion.h"
#include "ListaDobleCircular.h"
#include "Asiento.h"
#include "include/toon.hpp"

class Modelo;  // Forward declaration

class Reserva {
private:
    Usuario* usuario;
    Funcion* funcion;
    ListaDobleCircular<Asiento*>* asientosSeleccionados;
    double total;
    std::string fecha;  // Fecha de la reserva
public:
    Reserva(Usuario* u, Funcion* f, ListaDobleCircular<Asiento*>& a, double t, std::string fechaRes = "");
    ~Reserva();
    Usuario* getUsuario() { return usuario; }
    Funcion* getFuncion() { return funcion; }
    ListaDobleCircular<Asiento*>& getAsientos() { return *asientosSeleccionados; }
    double getTotal() { return total; }
    std::string getFecha() { return fecha; }
    void setFecha(std::string f) { fecha = f; }
    toon::TOON toToon() const;
    static Reserva* fromToon(const toon::TOON& t, Modelo* modelo);
};

#endif