#ifndef SALA_H
#define SALA_H

#include "Asiento.h"
#include "ListaDobleCircular.h"

class Sala {
private:
    int id;
    ListaDobleCircular<Asiento*> asientos;
public:
    Sala(int i);
    int getId() { return id; }
    ListaDobleCircular<Asiento*>& getAsientos() { return asientos; }
    void mostrarAsientos();
    Asiento* buscarAsientoPorId(std::string id);
    int contarAsientosDisponibles();
    int contarAsientosOcupados();
};

#endif