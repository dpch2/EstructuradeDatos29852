#ifndef VISTA_H
#define VISTA_H

#include <iostream>
#include <string>

class Vista {
public:
    void mostrarMenu();
    void mostrarMenuAsientos();
    void mostrarMensaje(std::string mensaje);
    int leerInt(std::string prompt);
    int leerIntEnRango(std::string prompt, int min, int max);
    std::string leerString(std::string prompt);
};

#endif